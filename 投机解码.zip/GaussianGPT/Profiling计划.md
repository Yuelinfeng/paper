# GaussianGPT 推理 Profiling 实验计划

**版本：** v1.0  
**实验平台：** NVIDIA GeForce RTX 4090  
**研究对象：** GaussianGPT 官方推理实现  
**主要 checkpoint：** `gpt_vfront.ckpt + vqvae_vfront.ckpt`  
**验证 checkpoint：** 第二组官方 checkpoint  
**当前阶段：** 官方单 Chunk 无条件生成已完成端到端复现，进入性能 Profiling 阶段

---

# 1. 实验背景与当前状态

目前已经完成 GaussianGPT 官方推理环境及核心推理流程复现。

已验证环境包括：

|组件|当前状态|
|---|---|
|PyTorch 2.8.0+cu129|正常|
|CUDA Runtime 12.9|正常|
|RTX 4090 / sm_89|正常|
|MinkowskiEngine 0.5.9|正常|
|gsplat 1.5.0|正常|
|PyTorch3D 0.7.8|正常|
|FlashAttention 2.8.2 package|已安装|
|GPT checkpoint|正常加载|
|VQ-VAE checkpoint|正常加载|
|自回归 token generation|正常|
|VQ-VAE Gaussian decoding|正常|
|`.pt` Gaussian scene|正常|
|Top-down rendering|正常|

当前已经获得一次真实官方推理结果：

```text
Generated token lengths: [3948]
Batch 1/1 completed in 62.51s
Generated 1 samples in 62.53s
```

输出：

```text
sample_0000.pt                  ≈ 12 MB
sample_0000_topdown_q75.png     ≈ 501 KB
```

因此，目前已经完成：

> **GaussianGPT Single-Chunk Unconditional Inference 的端到端复现。**

后续 profiling 不再处理环境安装问题，重点分析模型推理性能。

---

# 2. 一个必须首先明确的实现事实

当前 RTX 4090 上的 GaussianGPT GPT attention 路径需要特别说明。

虽然环境中已经安装：

```text
flash_attn 2.8.2
```

但 GaussianGPT 当前源码：

```text
model/gpt/flash_attention.py
```

的实际逻辑是：

```text
Hopper / sm90+
    → FlashAttention 3

RTX 4090 / sm89
    → PyTorch SDPA fallback
```

因此在我们的 RTX 4090 上：

> **GaussianGPT 当前 GPT 推理实际 attention backend 是 PyTorch SDPA，而不是已安装的 flash-attn 2.8.2 CUDA kernel。**

源码中的 KV-cache 接口仍然模拟：

```text
flash_attn_with_kvcache()
```

但 4090 最终走的是 SDPA fallback：

```text
Q
K cache
V cache
 ↓
PyTorch scaled_dot_product_attention
```

这一点必须写入实验记录。

因此本实验得到的性能结果严格描述为：

> **GaussianGPT 官方当前代码在 RTX 4090 / PyTorch SDPA inference backend 下的性能。**

不能直接推广到 H100/FA3。

---

# 3. 实验总体目标

本实验试图回答三个核心问题。

## RQ1：自回归循环占 GaussianGPT 推理过程多少时间？

需要回答：

> GaussianGPT 的时间主要花在 GPT token-by-token generation，还是 VQ-VAE decoding、Gaussian 构建和 rendering？

重点测量：

```text
Model load
Torch compile / warmup
Prefill
KV Cache allocation
Autoregressive decode loop
Sampling
Token post-processing
VQ-VAE decoding
Gaussian serialization
Rendering
```

核心指标：

RARcore=TARTprefill+TAR+Tpost+TVQVAE×100%R_{AR}^{core} = \frac{T_{AR}} {T_{prefill}+T_{AR}+T_{post}+T_{VQVAE}} \times100\%

以及：

RARE2E=TARTinference+Trender×100%R_{AR}^{E2E} = \frac{T_{AR}} {T_{inference}+T_{render}} \times100\%

需要同时报告两个百分比，避免“推理过程”定义不明确。

---

# 4. RQ2：自回归推理阶段 GPU 利用率如何？

重点研究：

> GaussianGPT 的 token-by-token decoding 是否能够充分利用 RTX 4090？

需要测量：

- GPU utilization
    
- GPU memory utilization
    
- GPU memory allocated
    
- GPU memory reserved
    
- SM activity
    
- kernel duration
    
- kernel launch frequency
    
- kernel 之间的 idle gap
    
- CPU→GPU launch 间隔
    
- GPU→CPU synchronization
    
- GPU power
    
- GPU clock
    
- tokens/s
    
- 单 token latency
    

特别关注当前源码中的：

```python
next_ids = sample_next_token(...)
sampled_tokens = next_ids[:, 0].tolist()
```

其中：

```python
.tolist()
```

可能导致 GPU→CPU synchronization。

之后代码又执行：

```python
ids = torch.tensor(token_column, device=device).unsqueeze(1)
```

形成：

```text
GPU sampling
   ↓
GPU → CPU synchronization
   ↓
Python list processing
   ↓
CPU tensor construction
   ↓
GPU
   ↓
next model.forward()
```

这可能成为自回归 decoding 中的重要 host-side overhead。

本实验需要验证，而不是预先假定该问题成立。

---

# 5. RQ3：KV Cache 如何随序列长度增长？

GaussianGPT 当前的 KV Cache 结构为：

```text
K cache:
[n_layer, batch, max_seq_len, n_kv_head, head_dim]

V cache:
[n_layer, batch, max_seq_len, n_kv_head, head_dim]
```

当前 `gpt.yaml`：

```text
n_embd     = 1024
n_layer    = 24
n_head     = 16
n_kv_head  = 16
n_ctx      = 16384
```

因此：

head_dim=102416=64head\_dim=\frac{1024}{16}=64

逻辑 KV cache 大小：

MKV(t)=2×L×B×t×HKV×D×SdtypeM_{KV}(t) = 2\times L\times B\times t\times H_{KV}\times D\times S_{dtype}

其中：

```text
2       = K + V
L       = 24
B       = batch size
t       = 当前 sequence length
H_KV    = 16
D       = 64
S_dtype = 每元素字节数
```

如果模型使用 FP16/BF16：

```text
S_dtype = 2 bytes
```

则：

MKV/token=2×24×16×64×2=98,304 bytesM_{KV/token} = 2\times24\times16\times64\times2 = 98,304\ bytes

约为：

```text
96 KiB / token / batch
```

因此理论上：

|Sequence length|Logical KV|
|--:|--:|
|256|≈ 24 MiB|
|512|≈ 48 MiB|
|1024|≈ 96 MiB|
|2048|≈ 192 MiB|
|4096|≈ 384 MiB|
|8192|≈ 768 MiB|
|16384|≈ 1536 MiB|

实际值必须根据运行时 dtype 再确认。

---

# 6. GaussianGPT KV Cache 的特殊点

当前实现不是动态增长式 KV allocation。

`Engine.generate()` 在 generation 开始时创建：

```python
KVCache(
    batch_size=...,
    seq_len=kv_length_hint,
    ...
)
```

内部立即：

```python
torch.zeros(
    num_layers,
    batch_size,
    seq_len,
    num_heads,
    head_dim
)
```

分别建立 K 和 V。

因此必须区分两个概念。

## Logical KV usage

实际已经生成 token 对应的有效 KV：

```text
token 1      → 1 token KV
token 512    → 512 token KV
token 4096   → 4096 token KV
...
```

它会随 sequence length 线性增长。

## Physical KV allocation

KV tensor 在生成开始之前已经按照 `max_seq_len` 预分配。

因此可能出现：

```text
Logical KV

Memory
  │              /
  │            /
  │          /
  │        /
  │      /
  │____/____________ Sequence
```

但是：

```text
Physical allocated KV

Memory
  │──────────────────
  │
  │
  │
  │
  └────────────────── Sequence
```

所以实验必须同时记录：

```text
logical_KV_MB
physical_KV_tensor_MB
torch_memory_allocated_MB
torch_memory_reserved_MB
```

不能仅通过 `nvidia-smi memory.used` 判断 KV cache 增长方式。

---

# 7. 附加研究问题

除三个主问题外，建议同时回答：

## RQ4

> token 序列变长以后，单 token decoding latency 是否增加？

## RQ5

> GPU utilization 是否随着 sequence length 增加而提高？

## RQ6

> top-p sampling、Python control flow 和 GPU synchronization 分别贡献多少额外开销？

## RQ7

> GaussianGPT 当前瓶颈究竟属于 compute-bound、memory-bound，还是 host-bound？

这些问题会直接决定后续 speculative decoding 的优化空间。

---

# 8. 实验假设

正式实验前定义以下待验证假设。

### H1

GaussianGPT 的主要推理时间消耗在 GPT autoregressive decoding loop，而不是 VQ-VAE decoding。

### H2

Batch size = 1、single-token decoding 导致 RTX 4090 GPU 利用率较低。

### H3

Python 自回归循环及 `.tolist()` 会产生频繁 CPU/GPU synchronization。

### H4

随着 context length 增长，attention 每 token 成本增加，因此 tokens/s 逐渐下降。

### H5

Logical KV cache 随 sequence length 线性增长，但 physical KV tensor 由于预分配机制不会随 token 逐步增长。

### H6

提高 batch size 可以提高 GPU utilization，但同时线性增加 KV cache memory。

这些全部属于实验假设，不作为预设结论。

---

# 9. 实验代码原则

不要直接大幅修改：

```text
generate_chunks.py
engine.py
gaussian_gpt.py
```

保留官方 baseline。

新增：

```text
profiling/
├── profile_inference.py
├── profile_engine.py
├── gpu_monitor.py
├── analyze_profile.py
├── configs/
├── raw/
├── traces/
└── results/
```

推荐结构：

```text
GaussianGPT/
├── 原官方代码
│
├── profiling/
│   ├── profile_inference.py
│   ├── gpu_monitor.py
│   ├── analyze_profile.py
│   ├── raw/
│   ├── traces/
│   └── figures/
│
└── outputs/
```

目标是：

> Profiling instrumentation 与模型算法修改分离。

未来 speculative decoding 再建立独立分支。

---

# 10. 实验环境冻结

正式实验前记录：

```bash
git rev-parse HEAD
git status
```

同时保存：

```bash
python --version
python -m pip freeze
nvidia-smi
nvcc --version
```

至少记录：

```text
Git commit
Python
PyTorch
CUDA Runtime
CUDA Toolkit
GPU
GPU Driver
MinkowskiEngine
FlashAttention package
attention backend
checkpoint
checkpoint SHA256
```

实验期间禁止：

```text
更新 PyTorch
更新 CUDA
更新 GaussianGPT
修改 checkpoint
修改 GPU power limit
同时运行其他 GPU workload
```

---

# 11. Profiling 时间边界

需要严格定义以下阶段。

## Stage A — Model Load

```text
load VQ-VAE checkpoint
load GPT checkpoint
move model to GPU
```

记为：

TloadT_{load}

---

## Stage B — Compile / Warmup

GaussianGPT 有：

```python
torch.compile(model)
```

第一次执行可能包含 compilation。

因此必须单独记录：

TwarmupT_{warmup}

但 steady-state baseline 中不计入正式 inference latency。

---

## Stage C — Prefill

官方无条件生成 prompt 基本只有 BOS/EOS token。

记为：

TprefillT_{prefill}

---

## Stage D — KV Allocation

创建：

```text
K cache
V cache
token cache
```

记为：

TKVallocT_{KValloc}

---

## Stage E — Autoregressive Loop

即：

```python
while True:
    sample token
    CPU state update
    model.forward(one token)
```

记为：

TART_{AR}

---

## Stage F — Token Post-processing

包括：

```text
EOS search
PAD search
length normalization
position token conversion
feature token conversion
```

记为：

TpostT_{post}

---

## Stage G — VQ-VAE Decode

```text
tokens
  ↓
coords / feature_ids
  ↓
VQ-VAE decode
  ↓
Gaussian attributes
```

记为：

TVQVAET_{VQVAE}

---

## Stage H — Rendering

包括：

```text
Gaussian scene
↓
gsplat render
↓
PNG/GIF
```

记为：

TrenderT_{render}

---

# 12. AR Loop 内部继续拆分

这是本实验最关键的一层。

每轮：

```text
Iteration t

① sampling parameter resolution
② top-k / top-p
③ softmax
④ multinomial
⑤ tensor.tolist()
⑥ Python RowState update
⑦ new tensor construction
⑧ transformer forward
⑨ KV cache update
```

至少拆成：

TAR=Tsample+Tsync+Tpython+TforwardT_{AR} = T_{sample} + T_{sync} + T_{python} + T_{forward}

其中：

```text
T_sample   = logits → sampled token
T_sync     = GPU → CPU synchronization
T_python   = state/list processing
T_forward  = transformer one-token forward
```

这样才能判断 speculative decoding 优化的真正上限。

---

# 13. 实验 P0：Correctness Baseline

**状态：已完成。**

参数：

```text
checkpoint       = gpt_vfront.ckpt
vqvae            = vqvae_vfront.ckpt
batch            = 1
num_samples      = 1
temperature      = 0.9
top_p            = 0.9
render_gifs      = false
store_samples    = true
```

结果：

```text
generated_tokens = 3948
time             ≈ 62.51 s
Gaussian output  = success
render           = success
```

注意：

```text
62.51 s
```

只能视为 smoke-test latency。

不能作为最终 baseline，因为首次运行可能包含：

```text
torch.compile
kernel warmup
allocator warmup
```

---

# 14. 实验 P1：Steady-State Latency Breakdown

## 目标

回答：

> 自回归 loop 占 GaussianGPT inference 百分之多少？

## 方法

一个 Python process 中：

```text
Load model once
↓
Warmup
↓
Run 1
Run 2
Run 3
Run 4
Run 5
```

不能每一次重新启动：

```bash
python generate_chunks.py
```

否则 compile/load overhead 会重复出现。

## Development 阶段

```text
Warmup = 1
Measured runs = 3
```

## 最终论文结果

```text
Warmup = 2
Measured runs = 5
```

---

# 15. P1 输出指标

每次保存：

```text
generated_tokens
T_prefill_ms
T_kv_alloc_ms
T_ar_ms
T_sample_ms
T_sync_ms
T_python_ms
T_forward_ms
T_post_ms
T_vqvae_ms
T_save_ms
T_core_ms
T_e2e_ms
tokens_per_second
ms_per_token
```

计算：

Throughput=NtokensTARThroughput=\frac{N_{tokens}}{T_{AR}} Latencytoken=TARNtokensLatency_{token}=\frac{T_{AR}}{N_{tokens}}

以及：

AR Ratiocore=TARTprefill+TAR+Tpost+TVQVAEAR\ Ratio_{core} = \frac{T_{AR}} {T_{prefill}+T_{AR}+T_{post}+T_{VQVAE}}

---

# 16. 实验 P2：GPU Utilization Profiling

## 目标

回答：

> AR loop 是否能够持续利用 GPU？

记录：

```text
timestamp
GPU utilization %
memory utilization %
memory.used
power.draw
SM clock
memory clock
temperature
```

推荐 50–100 ms sampling。

例如：

```bash
nvidia-smi \
  --query-gpu=timestamp,utilization.gpu,utilization.memory,memory.used,power.draw,clocks.sm,clocks.mem,temperature.gpu \
  --format=csv \
  -lms 100
```

输出到：

```text
profiling/raw/gpu_util_vfront.csv
```

同时 profile 脚本记录：

```text
generation_start
generation_end
token index
```

之后按时间戳对齐。

---

# 17. GPU Utilization 主要指标

报告：

```text
GPU util mean
GPU util median
GPU util P10
GPU util P90
GPU util P95
GPU util max
GPU memory mean
GPU memory peak
GPU power mean
```

并绘制：

```text
GPU Utilization (%)
100 ┤
 80 ┤
 60 ┤
 40 ┤
 20 ┤
  0 ┼──────────────────────
    token / time
```

同时叠加：

```text
token index
sequence length
```

观察 utilization 是否随 context length 变化。

---

# 18. 实验 P3：Sequence-Length Scaling

这是整个 profiling 最重要的一组实验。

## 目标

研究：

```text
sequence length
        ↓
per-token latency
GPU utilization
KV cache
tokens/s
attention cost
```

---

# 19. 固定 sequence length 实验

不能使用自然 EOS termination 来比较不同 sequence length。

原因是不同随机 seed 会生成不同长度：

```text
scene A = 3948
scene B = 2712
scene C = 6231
```

变量无法严格控制。

因此需要建立：

> **Forced-Length GPT-only profiling mode**

设置：

```text
stop_on_eos = false
```

并且不进行 VQ-VAE decode。

长度：

```text
256
512
1024
2048
4096
8192
```

最后增加边界测试：

```text
16384
```

16384 在前面长度均稳定后再运行。

---

# 20. Sequence-length 实验控制变量

固定：

```text
checkpoint      = gpt_vfront
batch           = 1
temperature     = 0.9
top_p           = 0.9
top_k           = None
seed            = fixed
dtype           = unchanged
GPU             = same RTX 4090
```

唯一主要变量：

```text
max_new_tokens
```

---

# 21. P3 每个长度记录

```text
sequence_length
total_AR_time
tokens_per_second
average_ms_per_token
GPU_util_mean
GPU_util_p95
GPU_memory
logical_KV_MB
physical_KV_MB
peak_allocated_MB
peak_reserved_MB
```

最终表：

|Seq Len|ms/token|tok/s|GPU util|Logical KV|Physical KV|
|--:|--:|--:|--:|--:|--:|
|256||||||
|512||||||
|1024||||||
|2048||||||
|4096||||||
|8192||||||
|16384||||||

---

# 22. Token-Latency 随序列增长分析

不能只测：

```text
total_time / tokens
```

还应将一个长 sequence 分段。

例如 8192-token generation：

```text
1–256
257–512
513–1024
1025–2048
2049–4096
4097–8192
```

计算每个区间：

```text
mean ms/token
median ms/token
tok/s
GPU util
```

得到：

```text
ms/token
  │
  │                  /
  │               /
  │            /
  │         /
  │______/
  └──────────────── Sequence Length
```

这可以直接揭示 attention context growth 的影响。

---

# 23. CUDA Memory 测量

每个 experiment 前：

```python
torch.cuda.reset_peak_memory_stats()
```

记录：

```python
torch.cuda.memory_allocated()
torch.cuda.memory_reserved()
torch.cuda.max_memory_allocated()
torch.cuda.max_memory_reserved()
```

分别在：

```text
model loaded
KV allocated
prefill complete
25% sequence
50% sequence
75% sequence
generation complete
VQ-VAE complete
```

采样。

---

# 24. KV Cache 独立记录

必须直接访问：

```text
kv_cache.k_cache
kv_cache.v_cache
kv_cache.cache_seqlens
```

计算：

```python
tensor_bytes =
    tensor.numel() * tensor.element_size()
```

记录：

```text
kv_dtype
kv_shape
kv_capacity_tokens
kv_used_tokens
kv_K_bytes
kv_V_bytes
kv_total_bytes
```

每隔：

```text
256 tokens
```

采样一次 `cache_seqlens`。

---

# 25. 实验 P4：Batch Size Scaling

为了验证低 GPU utilization 是否主要来自 batch=1，测试：

```text
B = 1
B = 2
B = 4
```

如果显存允许，再：

```text
B = 8
```

固定：

```text
sequence length = 2048
```

比较：

|Batch|Aggregate tok/s|tok/s/sample|GPU util|KV memory|Peak VRAM|
|--:|--:|--:|--:|--:|--:|
|1||||||
|2||||||
|4||||||
|8||||||

目的不是优化 production throughput，而是判断：

> GPU utilization 低是模型本身计算量不足，还是 batch=1 导致 hardware under-utilization。

---

# 26. 实验 P5：Sampling Overhead Ablation

当前 baseline：

```text
temperature = 0.9
top_p = 0.9
```

而 top-p 实现需要：

```text
sort logits
softmax
cumsum
mask
scatter
softmax
multinomial
```

可能产生不可忽略的开销。

测试：

### S1 — Baseline

```text
temperature = 0.9
top_p = 0.9
```

### S2 — No nucleus filtering

```text
temperature = 0.9
top_p = 1.0
```

### S3 — Greedy

```text
temperature = 0
```

固定：

```text
sequence length = 2048
batch = 1
```

比较：

```text
T_sample
T_forward
T_AR
tokens/s
GPU utilization
```

由此区分：

```text
Transformer bottleneck
vs
Sampling bottleneck
```

---

# 27. 实验 P6：CPU/GPU Synchronization 分析

重点关注：

```python
next_ids[:, 0].tolist()
```

需要通过 Nsight Systems 判断：

```text
CUDA kernel
    ↓
host wait
    ↓
Python
    ↓
CUDA launch
```

是否在每个 token 重复出现。

最终关注：

```text
cudaDeviceSynchronize
cudaStreamSynchronize
D2H synchronization
CPU idle/wait
GPU idle gap
```

如果大量出现：

```text
kernel
--- idle ---
kernel
--- idle ---
kernel
```

则说明 host launch / synchronization 是重要瓶颈。

---

# 28. PyTorch Profiler 实验

不建议直接 profile 完整 4000–16000 token。

原因：

```text
trace 太大
profiling overhead 太高
可能严重改变真实性能
```

推荐只 profile：

```text
64–128 consecutive tokens
```

例如在 sequence length ≈ 1024 时捕获：

```text
tokens 1024–1088
```

开启：

```text
CPU activity
CUDA activity
record_shapes
profile_memory
with_stack
```

分析：

```text
aten::linear
aten::mm / matmul
scaled_dot_product_attention
softmax
sort
multinomial
copy
tolist-related synchronization
```

---

# 29. Nsight Systems 实验

推荐使用 NVTX 标记：

```text
PREFILL
KV_ALLOC
AR_LOOP
TOKEN_SAMPLE
MODEL_FORWARD
POST_PROCESS
VQVAE_DECODE
RENDER
```

然后运行：

```bash
nsys profile \
  -t cuda,nvtx,osrt \
  -o profiling/traces/vfront_ar \
  --force-overwrite=true \
  python profiling/profile_inference.py ...
```

重点分析：

```text
CPU thread
Python runtime
CUDA API
CUDA kernel
GPU idle
kernel launch gap
memory copies
synchronization
```

---

# 30. Nsight Compute（可选）

如果需要回答：

> GPU kernel 本身到底是 compute-bound 还是 memory-bound？

再对代表性 token forward 使用 Nsight Compute。

主要看：

```text
SM Throughput
Memory Throughput
Achieved Occupancy
DRAM Throughput
Tensor Core utilization
L2 hit rate
```

Nsight Compute 开销非常大，因此只分析少量 representative token。

例如：

```text
sequence ≈ 512
sequence ≈ 2048
sequence ≈ 8192
```

各选一个 decoding step。

---

# 31. 实验 P7：第二组 checkpoint 验证

第一阶段所有实验都使用：

```text
gpt_vfront
vqvae_vfront
```

完成核心结论后，再用第二组官方 checkpoint 验证关键结果。

不需要重新跑所有实验。

仅重复：

```text
P1 Latency Breakdown
P2 GPU Utilization
P3 2048 / 4096 token scaling
```

目的：

> 检查结果是否仅由某一个 checkpoint 导致。

---

# 32. 实验 P8：Large-Scene Inference

第一阶段 profiling 完成后，再进入：

```text
generate_scene.py
```

Large-scene generation 会多次执行 chunk-level autoregressive generation，因此它是 speculative decoding 更实际的 end-to-end evaluation。

届时分析：

```text
chunk generation count
per-chunk AR time
total AR time
scene decode
top-down render
end-to-end scene generation time
```

但不能在当前阶段和 Single-Chunk baseline 混在一起。

---

# 33. 实验执行顺序

严格按照：

```text
P0 Correctness
      ↓
P1 Timing Breakdown
      ↓
P2 GPU Utilization
      ↓
P3 Sequence Scaling
      ↓
P4 Batch Scaling
      ↓
P5 Sampling Ablation
      ↓
P6 Nsight Synchronization
      ↓
P7 Second Checkpoint
      ↓
P8 Large Scene
```

不要一开始就跑 Nsight。

先用低开销 instrumentation 找到问题，再用高开销 profiler 定位原因。

---

# 34. 重复实验策略

开发阶段：

```text
warmup = 1
repeat = 3
```

最终结果：

```text
warmup = 2
repeat = 5
```

长序列 16384 如果成本过高：

```text
repeat = 3
```

必须保证所有 repeat：

```text
同一个 Python process
同一个模型实例
同一个 GPU
```

---

# 35. 统计方式

主要结果使用：

```text
Median
```

同时保存：

```text
Mean
Std
P25
P75
Min
Max
```

最终建议报告：

```text
Median ± IQR
```

而不是只报告一次运行。

---

# 36. Randomness 控制

记录：

```text
Python seed
PyTorch seed
CUDA seed
GaussianGPT sampling seed
```

性能 scaling 实验：

```text
fixed seed
```

自然 generation 实验：

```text
5 seeds
```

原因是 EOS 会导致自然生成长度变化。

---

# 37. GPU 环境控制

每轮实验前检查：

```bash
nvidia-smi
```

确保没有：

```text
其他训练任务
其他 CUDA process
GUI workload
额外推理进程
```

记录：

```text
temperature
power
SM clock
memory clock
```

GPU 温度过高产生 thermal throttling 时结果无效。

---

# 38. Raw Data Schema

每个 run 保存一行：

```text
run_id
timestamp
git_commit
checkpoint
seed
batch_size
max_tokens
generated_tokens
temperature
top_k
top_p
dtype
attention_backend
prefill_ms
kv_alloc_ms
ar_ms
sample_ms
sync_ms
python_ms
forward_ms
postprocess_ms
vqvae_ms
render_ms
core_ms
e2e_ms
tokens_per_second
ms_per_token
gpu_util_mean
gpu_util_p50
gpu_util_p95
gpu_util_max
peak_memory_allocated_mb
peak_memory_reserved_mb
kv_logical_mb
kv_physical_mb
```

推荐：

```text
profiling/raw/results.csv
```

---

# 39. Sequence-bin Data Schema

单独保存：

```text
run_id
token_start
token_end
context_length
num_tokens
elapsed_ms
ms_per_token
tokens_per_second
gpu_util_mean
gpu_memory_mb
logical_kv_mb
```

例如：

```text
0–255
256–511
512–1023
1024–2047
2048–4095
4096–8191
```

---

# 40. 最终需要产生的核心图

## Figure 1 — Inference Time Breakdown

Stacked bar：

```text
Prefill
AR Loop
Post-processing
VQ-VAE
Rendering
```

直接回答 RQ1。

---

## Figure 2 — AR Loop 占比

```text
AR / Core inference
AR / E2E inference
```

两个百分比。

---

## Figure 3 — GPU Utilization Timeline

横轴：

```text
Time / Token
```

纵轴：

```text
GPU utilization %
```

叠加 sequence length。

---

## Figure 4 — Per-token Latency vs Sequence Length

```text
X = sequence length
Y = ms/token
```

回答 context scaling。

---

## Figure 5 — Throughput vs Sequence Length

```text
X = sequence length
Y = tokens/s
```

---

## Figure 6 — KV Cache Growth

同时画：

```text
Logical KV memory
Physical allocated KV memory
```

这是非常关键的一张图。

---

## Figure 7 — GPU Utilization vs Sequence Length

```text
256
512
1024
2048
4096
8192
```

---

## Figure 8 — Batch Scaling

```text
Batch size
vs
GPU utilization
vs
Throughput
```

---

## Figure 9 — Sampling Ablation

比较：

```text
top-p 0.9
top-p 1.0
greedy
```

---

## Figure 10 — Nsight Timeline

展示：

```text
CPU Python
GPU kernels
Synchronization
GPU idle gaps
```

为后续 speculative decoding 动机提供直接证据。

---

# 41. 最终核心结果表

建议最终形成：

|Metric|Result|
|---|--:|
|Natural generated length||
|Core inference latency||
|AR loop latency||
|AR/Core ratio||
|AR/E2E ratio||
|Mean ms/token||
|Median ms/token||
|Throughput||
|Mean GPU utilization||
|P95 GPU utilization||
|Peak VRAM||
|Logical KV @ 4K||
|Physical KV allocation||
|VQ-VAE latency||

---

# 42. Profiling 对 speculative decoding 的意义

如果实验发现：

```text
AR loop > 80% E2E
```

说明 speculative decoding 潜在端到端收益很高。

如果：

```text
AR loop ≈ 30%
VQ-VAE + render ≈ 70%
```

则即使 GPT 加速 2×，E2E 收益仍然有限。

因此必须先得到真实：

fARf_{AR}

再用 Amdahl 定律估计理论上限：

SE2E=1(1−fAR)+fARSARS_{E2E} = \frac{1} {(1-f_{AR})+\frac{f_{AR}}{S_{AR}}}

例如只有实验得到 `f_AR` 后，才有资格讨论：

```text
AR 2× speedup
AR 3× speedup
AR 4× speedup
```

对应多少 E2E speedup。

---

# 43. 对 speculative decoding 最关键的额外信息

后续还需要从 profiling 中获得：

```text
每 token target-model latency
attention 占每 token latency 比例
MLP 占比
sampling 占比
CPU synchronization 占比
GPU idle 比例
context-length scaling
KV memory pressure
```

这些指标会决定 speculative decoding 的设计。

例如：

### 情况 A

```text
GPU utilization低
Python synchronization高
```

更大的 speculative block 能减少：

```text
Python loop
GPU launch
host synchronization
```

潜在收益很大。

### 情况 B

```text
attention latency随context快速增长
```

则 speculative verification 对 KV reuse 和 attention computation 的设计更重要。

### 情况 C

```text
sampling/top-p占比很高
```

则仅减少 transformer forward 次数可能不足。

---

# 44. 当前项目阶段判定

截至目前：

```text
Environment reproduction       DONE
Official checkpoint loading    DONE
GPT inference                  DONE
KV-cache inference             DONE
VQ-VAE decoding                DONE
Gaussian generation            DONE
Rendering                      DONE
E2E single-chunk reproduction  DONE
```

当前正式进入：

```text
Profiling Phase
```

之后才进入：

```text
Speculative Decoding Design
        ↓
Implementation
        ↓
Speed Evaluation
        ↓
Quality Evaluation
```

---

# 45. 第一阶段完成标准

Profiling 第一阶段只有同时回答以下问题才算完成：

1. AR loop 占 Core inference 百分比是多少？
    
2. AR loop 占 E2E inference 百分比是多少？
    
3. steady-state tokens/s 是多少？
    
4. 平均和 P95 GPU utilization 是多少？
    
5. GPU 是否存在明显 idle gap？
    
6. `.tolist()` 等 host synchronization 是否显著？
    
7. per-token latency 如何随 context length 增长？
    
8. logical KV cache 如何增长？
    
9. physical KV cache 如何分配？
    
10. KV cache 占 VRAM 比例是多少？
    
11. batch 增大以后 GPU utilization 是否显著改善？
    
12. top-p sampling 占 AR loop 多少时间？
    
13. 当前瓶颈属于 compute、memory 还是 host-side overhead？
    
14. 根据实测 AR fraction，speculative decoding 最大可能带来多少 E2E speedup？
    

只有这些问题回答清楚以后，再开始 speculative decoding implementation。

---

# 46. 下一步实际开发任务

现在不再继续跑普通 `generate_chunks.py`。

下一步应首先实现：

```text
profiling/profile_inference.py
```

第一版只负责：

```text
模型一次加载
↓
warmup
↓
多次重复 inference
↓
准确分离：

Prefill
KV allocation
AR loop
Sampling
Forward
Post-processing
VQ-VAE decode
Total
↓
输出 CSV / JSON
```

第二版加入：

```text
KV cache sampling
CUDA memory
sequence bins
```

第三版加入：

```text
NVML GPU monitor
```

第四版加入：

```text
NVTX + Nsight Systems
```

即：

```text
V1 Timing
   ↓
V2 KV + Memory
   ↓
V3 GPU Utilization
   ↓
V4 Nsight
```

这一顺序可以最大限度避免 profiling instrumentation 本身干扰正常推理性能。

---

# 47. 最终实验主线

整个 profiling 部分最终可以压缩成三条论文式研究主线：

### Profiling Study 1 — Where does inference time go?

回答：

> GaussianGPT 的推理时间主要消耗在哪个阶段？

核心结果：

```text
AR loop percentage
```

### Profiling Study 2 — How efficiently does autoregressive decoding use the GPU?

回答：

> 单 token AR decoding 能否充分利用现代 GPU？

核心结果：

```text
GPU utilization
kernel timeline
CPU/GPU synchronization
```

### Profiling Study 3 — How does decoding scale with context length?

回答：

> 随着 Gaussian token sequence 增长，latency、throughput 和 KV cache 如何变化？

核心结果：

```text
ms/token vs sequence length
tokens/s vs sequence length
KV memory vs sequence length
GPU utilization vs sequence length
```

三组结果共同构成后续 speculative decoding 设计与加速实验的实验依据。