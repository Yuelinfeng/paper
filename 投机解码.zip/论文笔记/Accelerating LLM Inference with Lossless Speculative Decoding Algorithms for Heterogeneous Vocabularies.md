# 摘要
背景：加速LLM的推理是生成式人工智能的一个关键挑战。

解决方案：投机解码方法通过使用单个target forward pass 生成多个token来提供显著的效率增益。

问题：
- **现有SD要求草稿模型和目标模型共享相同的词汇表**。因此限制了可能的草稿模型数量，通常需要从头开始对草稿模型进行训练。

方法：提出了三种新的SD方法来消除这种共享词汇的限制。所有的方法都保留目标分布（无损），并且可以使用现成的模型，无需额外的训练或修改。

效果：
- 从实证结果来看，在摘要生成、编程和长上下文任务中，我们的算法相较于标准的自回归解码方法，速度显著提升，最高可达2.8倍。
- 通过使任何现成的模型都可以充当起草者并且无需重新培训，这项工作大大拓宽了 SD 框架在实践中的适用性

> [!summary] 这篇论文主要讨论的是在词汇表不同的情况下，如何用两个模型进行投机解码

# 1 Introduction
问题就是当前的拒绝采样算法，要在相同的词汇表中采样。

贡献：
- Algorithm 2：String-Level Exact Match, SLEM：设置共享中间表示——纯文本
- Algorithm 4：Token-Level Intersection, TLI：调整交集，基于token的方法
- Algorithm 3：String-Level Rejection Sampling, SLRS：新颖验证机制，在字符串级别实现拒绝采样
所有算法都是无损，输出保留目标分布

# 2 Movtivating Examples
## Algorithm 1（词表并集，T外设置为0）
1. 输出是否正确：Algorithm 1 仍然严格保持 target 分布。
2. 接受率是否最高：它不一定充分利用drafter的预测，因此可能不是最快的。
当 $p(t) ＜ q(t), t ∈ T$ 时，drafter在目标词表中的概率质量足够覆盖target的需求，简单的接受-拒绝方法可以达到最优接受率。

但如果 drafter 会生成目标词表中不存在的token：
$$
\exists d \in D, \quad q(d) \gt 0,d\notin T
$$
那么drafter的一部分概率落在T外，因此
$$
\sum_{t \in T}q(t) \lt 1
$$
而target的全部概率都位于自己的词表中：
$$
\sum_{t \in T}p(t) = 1
$$
所以不可能对每个$t \in T$ 都满足$p(t) \le q(t)$：如果逐项都不小于，求和后应有 $\sum q(t) \ge 1$，这与 $\sum q(t) \lt 1$ 矛盾。

例如：
```
目标：p(a)=0.5, p(b)=0.5
草稿：q(b)=0.5, q(c)=0.5, 其中 c 不属于目标词表
```
所以algorithm 1遇到`c`会直接拒绝。这样仍然正确，但`c`对应的文本可能可以重新切分成目标词表中的一个或多个token。简单方法没有利用这部分信息，因此浪费了50%的草稿概率质量。

>[!Summary] 
>**词表取并集、缺失位置补零**的方法是“**正确但可能低效**”的。它能保证输出分布不变，却会无条件拒绝target词表外的draft token，因此未必达到理论上的最大接受率。Theorem 4.1 应该是在说明如何通过跨词表映射或重新分词，进一步提高接受概率。
## Algorithm 4（词表交集，并重新归一化）
通过调整drafter的分布来改进算法1，使得采样不在目标词汇表中的token概率为0。这种调整是通过标准化drafter的分布来完成的，使得目标词汇表中的标记的概率之和为1。

首先定义交集上的原始概率总量：
$$
Z = \sum_{t \in T ∩ D}q(t)
$$
然后构造新的草稿分布：
$$
q'(x) = \begin{cases} \dfrac{q(x)}{Z}, & x \in T \cap D\\[6pt] 0, & x \notin T \cap D \end{cases}
$$
也就是：
1. 把不属于目标词表的draft token屏蔽掉；
2. 将剩下的概率重新归一化；
3. 使用标准推测解码验证q'产生的token

例如：
原始分布：
$$q(a) = q(b) = q(c) = \frac{1}{3}$$
交集为：
$$T ∩ D = {a, b}$$
交集中的总概率为：
$$
Z = q(a) + q(b) = \frac{2}{3}
$$
重新归一化后：
$$
q'(a) = \frac{\frac{1}{3}}{\frac{2}{3}} = \frac{1}{2}
$$
$$
q'(b) = \frac{\frac{1}{3}}{\frac{2}{3}} = \frac{1}{2}
$$
因此 drafter 不再浪费三分之一的机会去生成必然被拒绝的 $c$

### 问题
因为Algorithm 4仍然在做“token ID级别"的匹配：
> 只有同一个字符串 token 同时属于T和D，才能作为候选。

它没有认识到：
> 一个drafter token可能等价于多个target token 拼接出来的字符串。

例子：
$T=\{a\},  D=\{a, aa\}$，`aa`应当被接受，除非它是最后一个token。

Algorithm 1因为p(aa) = 0，`aa`必然拒绝

Algorithm 4因为 $T∩D=\{a\}$，`{aa}`不在交集中，因此屏蔽$q'(aa) = 0$

- Algorithm 4在跨tokenizer的整体生成效率上，仍可能不如字符串级方法

## Algorithm 2（字符串转换+重新分词+精确匹配）
algorithm 2——String-Level Exact Match(SLEM)，它不要求draft token 和 target token 在 ID 或边界上相同，而是用字符串作为中间表示。

流程是：
1. drafter用自己的tokenizer生成token：`["aa"]`
2. 将drafter token 解码为普通字符串：`"aa"`
3. 用target tokenizer 重新分词：`["a", "a"]`
4. target一次前向并行计算这些位置的分布
5. 从target的每个位置实际采样：`target samples = ["a", "a", ...]`
6. 逐个精确比较，接受第一个不一致位置之前的所有target token

# 3. Speculative Decoding for Heterogeneous Vocabularies with String-Level Verification
通过字符串级验证对异构词汇进行投机解码。

**Notation(符号)**
字符串可表达性、词表可表达性和分词函数

1. 词表是字符串的有限集合，也叫做tokens
2. 字符串可由词表表达
	- 如果存在字符串$b_1, b_2, b_3, ..., b_n \in B$，则说明字符串a可以被词表$B$所表示，其中$a= b_1 \oplus b_2 \oplus ... \oplus b_n$，$\oplus$ 定义为字符串连接。
3. 一个词表可由另一个词表表达
	- 如果A中所有字符串都可以用B表示，则词汇表A可用词汇表B表示，记为 $A\twoheadrightarrow B^*$，其中$B^*$ 是字符串连接下 $B$ 的克林闭包。
4. 相对于词汇表A对字符串s进行标记 是 将 $s$ 划分为token序列 $a_1, a_2, ..., a_n$ 的过程，其中 $a_1$ 是A中tokens的最长前缀，$a_2$ 是去除 $a_1$ 后 $A$ 中 $s$ 的最长前缀，以此类推。
---
设底层字符集为 $\Sigma$，所有有限字符串构成集合 $\Sigma^*$，空字符串记为 $\varepsilon$。

1. 词表
词表是有限字符串集合：
$$
A,B\subseteq \Sigma^*,\qquad |A|,|B|<\infty
$$

通常要求：
$$\varepsilon\notin A,\qquad \varepsilon\notin B$$
词表中的每个字符串称为一个 token。

2. 字符串拼接
定义字符串拼接运算：
$$\oplus:\Sigma^*\times\Sigma^*\rightarrow\Sigma^*$$
对于字符串 $x,y$，$x\oplus y$ 表示将 $y$ 接在 $x$ 后面。

3. Kleene 闭包
首先定义：
$$B^0=\{\varepsilon\}$$
对于 $n\ge 1$：
$$
B^n
=
\left\{
b_1\oplus b_2\oplus\cdots\oplus b_n
\mid b_1,\ldots,b_n\in B
\right\}
$$

那么 $B$ 在字符串拼接下的 Kleene 闭包为：
$$B^*=\bigcup_{n=0}^{\infty}B^n$$
即 $B^*$ 包含所有能由有限个 $B$ 中 token 拼接得到的字符串。

4. 字符串的可表达性
字符串 $a\in\Sigma^*$ 可由词表 $B$ 表达，当且仅当：
$$a\in B^*$$
等价地：
$$\exists n\in\mathbb N,\ \exists b_1,\ldots,b_n\in B,
\quad
a=\bigoplus_{i=1}^{n}b_i
$$其中：
$$\bigoplus_{i=1}^{n}b_i
=
b_1\oplus b_2\oplus\cdots\oplus b_n$$

5. 词表的可表达性

词表 \(A\) 可由词表 \(B\) 表达，记为：
$$
A\twoheadrightarrow B^*
$$
其形式化定义为：
$$
A\twoheadrightarrow B^*
\iff
\forall a\in A,\ a\in B^*
$$
等价地：
$$A\twoheadrightarrow B^*
\iff
A\subseteq B^*
$$

进一步展开为：
$$
\forall a\in A,\ 
\exists n_a\in\mathbb N,\ 
\exists b_1,\ldots,b_{n_a}\in B,
\quad
a=\bigoplus_{j=1}^{n_a}b_j
$$
注意：
$$A\twoheadrightarrow B^*$$

并不要求 $A\subseteq B$，只要求 $A\subseteq B^*$。

6. 前缀关系

定义 $x\preceq s$ 表示 $x$ 是 $s$ 的前缀：
$$x\preceq s
\iff
\exists r\in\Sigma^*,\quad s=x\oplus r
$$

对于词表 \(A\) 和字符串 \(s\)，定义合法词表前缀集合：
$$P_A(s)=\{a\in A\mid a\preceq s\}$$

最长合法前缀函数定义为：
$$L_A(s)
=
\underset{a\in P_A(s)}{\operatorname{argmax}}\ |a|
$$
这里 $|a|$ 表示字符串 $a$ 的长度。

7. 贪心最长前缀分词

给定字符串 $s$，令初始剩余字符串为：
$$r_0=s$$
递归定义：
$$a_i=L_A(r_{i-1})$$

以及：
$$r_{i-1}=a_i\oplus r_i$$

一直执行到某个 \(n\) 满足：
$$r_n=\varepsilon$$

于是：
$$s=a_1\oplus a_2\oplus\cdots\oplus a_n$$

并且每一步都满足最长前缀条件：
$$a_i\in A$$
$$a_i\preceq r_{i-1}$$
$$
\forall a\in A,\quad
a\preceq r_{i-1}\Longrightarrow |a|\le |a_i|
$$

字符串 \(s\) 关于词表 \(A\) 的分词结果定义为：
$$A(s)=(a_1,a_2,\ldots,a_n)\in A^*$$

其中第 \(i\) 个 token 为：
$$A(s)_i=a_i\in A,\qquad 1\le i\le n$$
并满足解码一致性：
$$\bigoplus_{i=1}^{|A(s)|}A(s)_i=s$$

以上定义隐含假设：$s$ 可以被 $A$ 完整表达，并且最长前缀选择是唯一的；否则 $A(s)$ 可能未定义或需要额外的决胜规则。

---

## 3.1 String-Level Exact Match (SLEM)
算法 2 是解决异构词汇表问题的一种方案。

它实现了一种基于**精确匹配验证方法**的 SD 变体。

其核心机制在于在草稿词汇表和目标词汇表之间进行**双向令牌转换**。

由草稿生成器生成的令牌首先被解码为文本，随后使用目标模型的词汇表进行重新分词。

在目标模型验证生成的令牌后，该序列会被转换回起草器的分词格式，以供下一次迭代使用。

这一过程既确保了目标模型的分布得以保留，又允许起草器在自身的词汇约束范围内进行操作。

### 词汇限制
$$target token 序列 \leftrightarrows 字符串 \leftrightarrows draft token 序列$$
现实中通常满足这些条件，因为BPE、WordPiece、Unigram、SentencePiece等词表一版都包含基础字符或字节。即使双方的长token不同，也可以拆成基础单位互相表达。

---

算法 2 假设**目标词汇表 T 可用草稿词汇表 D 表示**，即 $T ↠ D^∗$。此外，它还假设 $D^∗ ↠ T^∗$，
也就是**两个词表中每个token都能被另一词表拆开表示**。

即每个草稿令牌的连接 $d_1 ⊕ . . . ⊕ d_i$（其中 i 为某个整数），必须能够通过目标令牌 $t_1⊕t_2⊕. . .⊕t_m ∈ T^∗$（其中 m 为某个整数）的串联来表示，即第 7 行中的 $T (d_1⊕. . .⊕d_i) ≠ ∅$。



## 3.2 Non-Injective Tokenizers
非注入式分词器

这一节 **3.2 Non-Injective Tokenizers** 主要是在解决 SLEM 的一个工程性陷阱：**当两个模型通过“文本”作为中间桥梁时，tokenizer 的 normalize / pre-tokenization 可能改变文本，从而破坏 draft 与 target 之间的对齐。**

先抓住这一句话即可：
> **SLEM 理论上通过 `token → text → token` 在不同 vocabulary 之间转换，但现实 tokenizer 不一定满足“编码再解码后文本完全不变”，因此反复跨 tokenizer 转换可能把已经生成的内容改掉。**

---

### 3.2.1. 什么叫 Non-Injective Tokenizer？

论文用的判断形式是：$$s \neq decode(encode(s))$$

也就是说，对某个原始字符串 ss：
```text
原始文本 s
   ↓ encode
token IDs
   ↓ decode
文本 s'
```

结果可能：
```text
s' ≠ s
```

论文举出的原因包括：
- 多个空格可能被折叠；
- 大小写可能被统一；
- 带重音字符可能被标准化。

例如为了理解，可以想象：
```text
原文本:
"Hello   World"

tokenizer:
encode → decode

得到:
"Hello World"
```

这里的信息已经丢了。

所以这里的 **non-injective**，你可以暂时理解成：
> **不同原始字符串可能经过 tokenizer 后变成无法区分的表示。**

---

### 3.3.2. 为什么普通自回归生成里这个问题通常没那么严重？

这是这节最关键的逻辑。

普通 AR decoding 或标准 homogeneous speculative decoding 中，prompt 只会在开始时 tokenize **一次**。

流程是：

```text
prompt c
   ↓
Tokenizer(c)
   ↓
Target Model
   ↓
t1, t2, t3, ...
```

之后模型生成的是 token ID。

最终返回：

```text
原始 prompt c
+
decode(t1)
+
decode(t2)
+
...
```

重点在于：

> **pre-tokenization / normalization 只作用于输入 prompt，不会反复作用于已经生成的输出 token。**

所以即使：

T(c)=T(c′)T(c)=T(c')

模型确实无法区分 cc 和 c′c'，但这种信息损失只发生在最初输入阶段。

已经生成的：

```text
t1, t2, ..., tN
```

不会重新经历：

```text
decode → encode → normalize
```

论文对此有明确解释。

所以标准生成中：

```text
tokenizer normalization
        ↓
只在入口发生一次
```

---

### 3.2.3. 为什么 SLEM 会把这个问题放大？

因为 SLEM 的核心恰恰是：
```text
Drafter Tokens
      ↓
    decode
      ↓
Plain Text
      ↓
Target Tokenizer
      ↓
Target Tokens
```

也就是说：
> **不同模型之间必须不断通过 plain text 转换。**

论文指出，当 $T\neq D$ 时，两个模型无法直接通过 token ID 通信，因此 Algorithm 2 使用 plain text 作为中间表示。

问题就在这里。

假设 Drafter 已经生成：
```text
"A   B"
```

Drafter 本来想表达：
```text
A + 三个空格 + B
```

但你执行：
```text
decode
↓
Target tokenizer encode
```

Target tokenizer 可能做 normalization：
```text
"A   B"
   ↓
"A B"
```

那么：
```text
Drafter 实际生成的字符串
≠
Target 实际看到的字符串
```

这就不只是“token boundary 不一样”了。

而是：
> **字符串本身发生了变化。**

论文明确指出，这会造成 target 看到的内容与 drafter 原本生成内容之间的 mismatch，并且作者实验中发现它会显著影响 acceptance rate。

---

### 3.2.4. 真正危险的地方：跨 iteration 后 token 会错位

SLEM 不是只执行一轮。

假设第一轮 Target 已经接受：

```text
Target token sequence:

[A] [B] [C] [D]
```

下一轮 Drafter 为了继续生成，需要知道当前上下文。

但如果你简单：

```text
Target Tokens
   ↓ decode
text
   ↓ Draft tokenizer
Draft Tokens
```

由于 tokenizer non-injective，重新 encode 后的 tokenization 可能变成：

```text
[A'] [B'] [C'] ...
```

甚至对应的字符串细节也发生变化。

于是出现一个麻烦：

```text
之前 target 已经确认的上下文
          ≠
重新 tokenize 后 drafter 理解的上下文
```

如果不处理，这种误差会随着 iteration 传播。

---

# 5. 作者的关键修复：不要每轮重新“相信整个字符串”

这一段是 3.2 的核心解决方案。

论文说：

> Algorithm 2 的输出本身已经处于 **target vocabulary** 中，因此后续 iteration 可以直接保留这些 target tokens，而不是每次把它们 decode 回文本再重新 tokenize。

也就是说：

### 错误思路

```text
Target accepted tokens
      ↓
decode entire history
      ↓
re-tokenize entire history
      ↓
继续生成
```

这种做法会重新触发 normalization。

---

### 作者思路

```text
已经接受的 Target Tokens
        │
        │ 保持不动
        ▼
     [A B C D]

新的 Draft Proposal
        ↓
      text
        ↓
Target tokenizer
        ↓
  [C' D' E F]
```

然后做：

> **sequence alignment**

---

# 6. Longest Overlap / suffix-prefix matching

论文的原话实际上非常重要：

作者会寻找：

> **already accepted target tokens** 与  
> **newly re-encoded target tokens**

之间最长的一段匹配。

本质上就是：

```text
旧序列 suffix
       vs
新序列 prefix
```

找最大 overlap。

例如：

```text
已接受 Target tokens:

A B C D E
    └─────┘


新 proposal 重新 tokenize 后:

      C D E F G
      └─────┘
```

找到最大 overlap：

```text
C D E
```

那么：

```text
旧:
A B C D E

新:
    C D E F G
```

最终只追加：

```text
F G
```

而不是把：

```text
C D E
```

再生成一次。

---

# 7. 为什么叫 “look behind”？

因为新的 tokenization 可能在边界处发生变化。

例如理论上：

```text
上一轮:
[A] [BC]

新文本追加 D 后重新 tokenize:
[A] [B] [CD]
```

这里新 token：

```text
[CD]
```

实际上跨过了上一轮的边界。

所以你不能只比较“最后一个 token”。

你需要稍微向前看几步：

```text
... A  BC
       ↑
    look behind
```

重新判断：

```text
旧 suffix
与
新 prefix
```

怎么对齐。

论文说算法可以 **look behind a small number of tokens**，从而重新对齐序列，并尽可能保留已经生成的文本。

---

# 8. 用一个完整例子理解

假设 Target 已接受：

```text
Target token sequence:

["Hello", " ", "world"]
```

现在 Drafter 继续生成：

```text
"   again"
```

拼起来是：

```text
"Hello world   again"
```

但 Draft tokenizer / Target tokenizer 对空格处理不同。

Target 重新 tokenize 新内容后可能看到：

```text
["world", " ", "again"]
```

而不是：

```text
["world", "   ", "again"]
```

如果我们粗暴把整个 history 重新 tokenize：

```text
旧历史可能被改变
```

作者的方法则是：

```text
旧 Target tokens:
["Hello", " ", "world"]

新 re-tokenized sequence:
["world", " ", "again"]

最大 overlap:
["world"]

因此只追加:
[" ", "again"]
```

注意：这个例子是为了帮助理解算法思想；论文给出的核心机制是最长 overlap / suffix-prefix matching，而不是这个具体字符串。其目标正是避免 normalization 导致已接受历史被破坏。

---

# 9. 你可以把整个 3.2 压缩成这张逻辑图

```text
SLEM
Draft Tokens
    ↓
decode
    ↓
Plain Text
    ↓
Target tokenize
    ↓
Target Tokens
```

正常情况：

```text
decode → encode
文本不变
```

但 Non-injective tokenizer：

```text
decode → normalize → encode
           ↓
      文本发生改变
           ↓
 Draft / Target 上下文错位
           ↓
 acceptance rate 下降
```

作者解决：

```text
保留已经接受的 Target Tokens
          +
新 proposal 重新 tokenize
          ↓
寻找
old suffix ↔ new prefix
最长 overlap
          ↓
只加入 overlap 之后的新 token
```

---

## 10. 这一节你真正应该记住的三点

**第一，问题不是简单的“两个 tokenizer token ID 不一样”。**

heterogeneous vocabulary 本来就已经解决 token ID 不同了。

3.2 处理的是更深一层的问题：

decode(encode(s))≠sdecode(encode(s))\neq s

也就是**文本本身可能因为 tokenizer normalization 发生变化**。

**第二，普通 AR 不严重，是因为 tokenizer 通常只在输入端作用一次；SLEM 严重，是因为它需要频繁跨 tokenizer 转换。**

**第三，作者没有要求 tokenizer 必须 injective，而是通过“保留 Target token history + overlap alignment + look-behind”让 SLEM 兼容 non-injective tokenizer。**

这也是这一节真正的贡献。