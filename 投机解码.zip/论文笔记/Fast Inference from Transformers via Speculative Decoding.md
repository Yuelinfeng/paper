# 摘要
- 场景——**自回归模型**推理速度较慢
- motivation：推测解码——并行计算token + 无损
- observation：
	- 难任务里往往夹着容易的子任务
	- 先推测，再并行验证，且严格保持原分布
- 效果：在T5-XXL上达到2到3倍加速效果，输出相同

# Introduction
## 背景
- 大型自回归模型能力比小模型更强
- 大型自回归模型的单词解码更慢，而且是串行执行

- 一些现有解决方法
	- 平等地降低所有输入的推理成本
	- **自适应计算方法：** 并非所有推理步骤都具有相同的特性——有些步骤需要非常庞大的模型，而另一些步骤则可以通过更高效的模型得到很好的近似。
- 自适应计算方法的问题：尽管其中许多方案在实践中已被证明极其有效，但它们通常需要**更改模型架构**、**调整训练流程**并**重新训练模型**，且**无法保持完全一致的输出结果**。

## observation
- 上文提到的关键观察结果——即**某些推理步骤“更难”，而某些则“更容易”**——也是我们开展这项研究的重要动因。
- 此外，我们还观察到，大型模型的推理过程通常并非受算术运算的限制，而是**受内存带宽和通信的限制**，因此可能还有额外的计算资源可用。

- 因此，我们建议**通过提高并发度**，作为采用自适应计算量方法的补充策略。
- 具体而言，我们能够在不改变模型架构、不改变训练流程、无需重新训练模型且不改变模型输出分布的情况下，加速推理过程。这是通过**投机执行**来实现的。

## Motivation
### 投机执行
- 投机执行（Burton，1985；Hennessy & Patterson，2012）是一种在处理器中常见的优化技术，其原理是在验证任务是否确实需要之前，先并行执行该任务——其好处在于提高了并发性。
- 投机执行的一个著名例子是**分支预测**。为了使投机执行有效，我们需要一种高效的机制，以推荐那些可能被需要的任务进行执行。

### 投机采样
- 在本研究中，我们将投机执行推广到**随机场景**——即某项任务以一定概率被需要。将其应用于Transformers等自回归模型的解码过程时，**我们从更高效的近似模型中采样生成的内容，作为较慢目标模型的投机性前缀**。通过一种新型采样方法——投机采样，我们在确保系统输出与仅使用目标模型时的输出具有相同分布的同时，最大限度地提高了这些投机性任务被采纳的概率。

![[Pasted image 20260915172435.png]]
- 例如，图 1 中由 38 个令牌组成的句子，得益于一个更小、更高效的近似模型（600 万个参数），我们的方法仅需对一个更大的目标模型（9700 万个参数）进行 9 次串行运行即可生成，而生成的概率保持不变。

## 结论
我们在多种任务和不同规模的模型上对该方法进行了分析：
- 基于在lm1b数据集上训练的9700万参数GPT类模型进行无条件生成；
- 使用110亿参数的T5-XXL模型进行英语至德语翻译和新闻文章摘要生成；
- 以及使用1370亿参数的LaMDA模型进行对话任务。

我们实现了该方法，并将 T5-XXL 的实际运行时间与稳健的 T5X 实现（Roberts 等，2022）进行了比较，结果表明，在不改变输出结果的情况下，开箱即用的**延迟降低了 2 到 3 倍**。我们的方法易于在实际生产环境中部署，无需训练新模型，也不会改变输出结果。

因此，在内存带宽是瓶颈且计算资源充足的常见情况下，加速 Transformers 等自回归模型的采样可能是一个不错的默认选择。

综上所述，我们的主要贡献包括：
(1) 将投机执行推广至随机场景，并提出了一种名为“投机采样”的新型采样方法；
(2) 提出了一种名为“投机解码”的解码机制，可在不改变模型架构、训练方案和输出分布的情况下，加速自回归模型的解码过程。

# Speculative Decoding
## 2.1 Overview
设 **$M_p$ 为目标模型**，我们试图加速其推理过程；
$p(x_t|x<t)$ 表示该模型针对前缀 $x<t$ 给出的分布。
设 **$M_q$ 是针对同一任务的更高效近似模型**，并用 $q(x_t|x<t_1)$ 表示该模型针对前缀 $x<t_1$ 给出的分布。

其核心思想是：
(1) 生成draft：使用更高效的模型 $M_q$ 生成 $γ ∈ Z^+$ 个补全结果
(2) 验证draft：使用目标模型 Mp 并行评估 Mq 生成的所有猜测及其对应概率，接受所有能导致相同分布的猜测
(3) 修正结果：从调整后的分布中采样一个额外的令牌，以修复第一个被拒绝的令牌，或者在所有令牌均被接受时添加一个额外的令牌。

这样，目标模型 $M_p$ 的每次并行运行都会产生至少一个新令牌，但根据 $M_q$ 对 $M_p$ 的逼近精度，它潜在可生成多达 $γ + 1$ 个新令牌。

论文中的 Speculative Decoding（推测解码）可以概括为：
> 先让“小模型快速起草多个 token”，再让“大模型一次性并行审核，从而减少大模型串行调用次数。

论文记号：
- $M_p$：目标模型（Target Model），生成质量高，但推理慢。
- $M_q$：近似模型（Draft/Approximation Model），规模较小，速度快。
- $p(x_t\mid x_{<t})$、$q(x_t\mid x_{<t})$：两个模型对下一个 token 的概率分布。
- $\gamma$：小模型每轮预先生成的 token 数量。

### 传统自回归解码

普通解码每次只能生成一个 token：
$$x_1 \rightarrow x_2 \rightarrow x_3 \rightarrow \cdots$$
每生成一个 token，都必须串行运行一次大模型。因此生成 \(N\) 个 token，通常需要大模型连续运行 \(N\) 次。

### Speculative Decoding 的一轮流程

假设 \($\gamma=4$\)。
1. 小模型快速起草
小模型 $M_q$ 自回归地产生 4 个候选 token：$x_1,x_2,x_3,x_4$
由于小模型便宜，这部分计算成本较低。

2. 大模型一次性审核
目标模型 $M_p$ 对下面这些位置的概率分布进行并行计算：$p_1,p_2,p_3,p_4,p_5$

其中：
- $p_1$：根据原始前缀预测 $x_1$
- $p_2$：根据“前缀+$x_1$”预测 $x_2$
- $p_3$：根据“前缀+$x_1,x_2$”预测 $x_3$
- 依此类推

Transformer 可以在一次前向传播中计算这些位置，因此不需要把大模型串行运行 5 次。

3. 依次接受候选 token
对于小模型生成的候选 $x_i$，其接受概率为：
$$\min\left(1,\frac{p_i(x_i)}{q_i(x_i)}\right)$$
直观地说：
- 如果大模型认为该 token 至少和小模型一样合理，就直接接受。
- 如果小模型过度高估了该 token，就只以 $p_i(x_i)/q_i(x_i)$ 的概率接受。

候选必须从左到右连续接受。一旦某个 token 被拒绝，后面的候选也全部丢弃，因为它们建立在错误前缀之上。

4. 补充一个由大模型决定的 token
- 如果某个候选被拒绝，就从修正分布
$$p'(x)=\operatorname{norm}\big(\max(0,p(x)-q(x))\big)$$
- 若$p(x) > q(x)$，小模型低估了$x$，还需要补上$p(x) - q(x)$
- 若$p(x) ≤ q(x)$，小模型没有低估$x$，接受阶段已经覆盖了目标概率，不应再补偿，因此设为0
重新采样一个 token，替换第一个被拒绝的候选。
> [!tip] 为什么不能直接从$p$重新采样？
> - 因为接受阶段已经贡献了一部分目标概率。如果拒绝后再完整地从$p$采样，就会重复计算这些概率，从而改变最终分布。
> - 正确做法是只采样目标分布中尚未被覆盖的部分：$min(p,q) + max(0, p - q) = p$
> - 因此，这个修正公式不是任意设计的；它正是为了补齐接受阶段缺少的概率，同时避免重复计算已经覆盖的概率

- 如果全部 $\gamma$ 个候选都被接受，则利用大模型已经算出的 $p_{\gamma+1}$，再生成一个额外 token。
因此，一轮大模型调用一定会产生至少 1 个 token，最多产生：$\gamma+1$个 token。

### 举例

小模型一次起草：
> “今天天气非常适合跑步”

假设大模型依次接受：
> “今天” → “天气” → “非常” → “适合”

但拒绝“跑步”，那么本轮输出可能是：
> “今天天气非常适合散步”

其中前四个 token 来自小模型，最后一个修正 token 来自大模型的修正分布。

### 最关键的性质

Speculative Decoding 并不是简单地“相信小模型”。它通过接受概率和修正分布保证：
$$\text{最终输出分布} = \text{仅使用目标模型时的输出分布}$$

所以理论上：
- 不改变目标模型的生成结果分布；
- 不需要重新训练目标模型；
- 最坏情况下每轮仍然生成一个 token，不会比普通串行解码需要更多的大模型串行轮次；
- 当小模型与大模型预测接近时，一次大模型调用可以确认多个 token，从而显著降低延迟。

论文 Figure 1 的例子中，38 个 token 只需要目标模型串行运行 9 次；论文报告在部分 T5-XXL 实验中取得了约 $2\text{–}3\times$ 的延迟改善。
## 2.2 标准化采样
首先需要注意的是，尽管采样方法和参数多种多样，例如 argmax、top-k、nucleus 以及温度设置等，且常见的实现方式通常在 logit 层面对它们进行差异化处理，但它们都可以轻松转化为**从调整后的概率分布中进行标准采样**。

> 不管使用temperature、top-k、top-p 还是argmax，都可以把原始概率分布转换成一个“调整后的概率分布”，然后统一描述为从该分布采样。

相当于是一个数学上的“接口层”，让后面的算法都能够同时适用于各种解码方法。

## 2.3 投机采样
- 为了抽样得到 $x ∼ p(x)$，我们改为抽样 $x ∼ q(x)$，
- 当 $q(x) ≤ p(x)$ 时保留该样本；
- 若 q(x) > p(x)，则以概率 $1− \frac{p(x)}{q(x)}$ 拒绝该样本，并改从调整后的分布 $p′(x) = norm(max(0, p(x) − q(x)))$ 中再次抽样 $x$。

不难证明，对于任意分布 p(x) 和 q(x)，以及按此方式采样的 x，x 确实服从 p(x)。
> [!note] 证明：现在我们将证明，对于任意两个分布 $p(x)$ 和 $q(x)$，通过投机采样从 p(x) 和 q(x) 中采样的令牌，其分布与仅从 p(x) 中采样的令牌完全相同。
> 


当$\gamma = 1$时，设当前已经生成的文本为$prefix$ 
1. 小模型先猜第一个token
	- $q_1(x) = M_q(prefix)$，然后采样：$x \sim q_1(x)$，这里的 $x_1$ 只是小模型提出的候选，尚未正式接受
2. 大模型同时计算两个位置
	- $p_1(x) = M_p(prefix)$，
	- $p_2(x) = M_p(prefix + [x_1])$，$x_2 \sim p_2(x)$
3. 根据$x_1$是否接受分情况处理
	- $x_1$ 被拒绝
		- 丢弃$x_1$ 以及 $p_2$
		- 修正分布，重新采样当前位置的token：$x_1' \sim norm(max(0, p_1(x) - q_1(x))$
		- 本轮只输出 $[x_1']$，生成一个token
	- $x_1$ 被接受
		- $prefix+[x_1]$ 成为了正确前缀。因此$p_2$有效，可以从中采样 $x_2$
		- 本轮输出$[x_1, x_2]$。$x_1$提出自小模型，$x_2$ 是由目标模型分布产生的额外token
![[Pasted image 20260915201703.png]]

# 3. Analysis
## 3.1 Number of Generated Tokens
> [!summary] 3.1的逻辑
> $M_q$ 越接近 $M_p$ $\Rightarrow$ $\alpha$ 越高 $\Rightarrow$ 连续接受的候选越多 $\Rightarrow$ 需要的目标模型串行轮数越少

- 分析对目标模型的串行调用次数的减少倍数；分析一下算法1单次运行所产生的令牌的预期数量。

**定义 3.1.** 给定前缀 $x<t$ 时，接受率 $β_x<t$ 是指根据第 2.3 节所述，通过推测性采样接受 $x_t ∼ q(x_t|x<t)$ 的概率。

因此，$E(β)$ 是衡量 $M_q$ 对 $M_p$ 的逼近程度的一种自然度量。如果我们做出一个简化假设，即 $β$ 值是独立同分布的，并设 $α = E(β)$，那么 Algorithm 1 单次运行生成的令牌数量是一个有上限的几何随机变量，其成功概率为 $1 − α$，上限为 $γ + 1$，且算法 1 生成的令牌期望数量满足以下方程 (1)。参见图 2。
$$\mathbb{E}(\# \text{generated tokens}) = \frac{1-\alpha^{\gamma+1}}{1-\alpha}$$
![[Pasted image 20260915203128.png]]
- $E(\beta)$ 是一种自然度量，它同时反映：
	- 两个模型概率分布的重合程度
	- 小模型候选实际被接受的频率
	- speculative decoding实际能够获得的加速程度

## 3.2 Calculating $\alpha$
3.1 先说明**如果知道 $\alpha$，就能预测一次生成多少token**，那3.2说明**那么$\alpha$ 到底如何从 $p$ 和 $q$ 计算**

### **Definition 3.2.** 
所以接下来推导一个公式，用于在给定一个前缀以及两个模型$M_p$和$M_q$的情况下计算$\alpha$。首先，我们定义一个自然散度 $D_{LK}$：
因为：
$$
M(x)=\frac{p(x)+q(x)}{2}
$$
所以：
$$
{D_{LK}} = \sum_x|p(x)-M(x)| = \sum_x|q(x) -M(x)|
$$
代入得：
$$
{D_{LK}}(p,q) = \frac12\sum_x|p(x)-q(x)|
$$
### **Lemma 3.3.**
$D_{LK}(p,q)=1-\sum_x\min(p(x),q(x))$，其中$D_{LK}(p,q)=\frac12\sum_x|p(x)-q(x)|$
推导过程：
- 利用恒等式$\min(a,b)=\frac{a+b-|a-b|}{2}$，可得
$$
\begin{aligned}
\sum_x\min(p(x),q(x))
&=\sum_x\frac{p(x)+q(x)-|p(x)-q(x)|}{2}\\
&=\frac12\left(
\sum_xp(x)+\sum_xq(x)-\sum_x|p(x)-q(x)|
\right)
\end{aligned}
$$
因为 $p,q$ 都是概率分布：$$\sum_xp(x)=\sum_xq(x)=1$$
所以：
$$
\begin{aligned}
\sum_x\min(p(x),q(x))
&=1-\frac12\sum_x|p(x)-q(x)|\\
&=1-D_{LK}(p,q)
\end{aligned}
$$
移项即得：$$D_{LK}(p,q)=1-\sum_x\min(p(x),q(x))$$
直观含义
$$\sum_x\min(p(x),q(x))$$
表示两个概率分布重合的概率质量，因此：$$\boxed{\text{分布差异}=1-\text{分布重合部分}}$$
例如：
$$
p=(0.7,0.3),\qquad q=(0.4,0.6)
$$

重合部分为：
$$
\min(0.7,0.4)+\min(0.3,0.6)
=0.4+0.3=0.7
$$

所以：
$$
D_{LK}(p,q)=1-0.7=0.3
$$

这个引理随后用于证明接受率：
$$
\beta=\sum_x\min(p(x),q(x))=1-D_{LK}(p,q)
$$
即两个模型的分布越接近，候选 token 的接受率越高。

这三个结论构成了一条完整逻辑链：
$$
D_{LK}(p,q)
\longrightarrow
\beta
\longrightarrow
\alpha
$$

### Corollary 3.4：$D_{LK}$ 的基本性质
$$
\boxed{D_{LK}(p,q)\in[0,1]}
$$
并且：
$$
D_{LK}(p,q)=D_{LK}(q,p)
$$
所以它是对称的分布差异度量。

另外：
$$
\boxed{D_{LK}(p,q)=0\iff p=q}
$$
即两个分布完全相同时，距离为 0。

以及：
$$
\boxed{
D_{LK}(p,q)=1
\iff
p,q\text{ 的支撑集不相交}
}
$$

“支撑集不相交”指不存在任何 token 同时满足：
$$
p(x)>0,\qquad q(x)>0
$$

这些结论可以直接由 Lemma 3.3 得到：
$$
D_{LK}(p,q)=1-\sum_x\min(p(x),q(x))
$$

因为重合概率：
$$
\sum_x\min(p(x),q(x))
$$

一定在 $[0,1]$ 之间。
- 完全重合：重合量为 1，\(D_{LK}=0\)；
- 完全不重合：重合量为 0，\(D_{LK}=1\)。

### Theorem 3.5：接受率与分布距离的关系

定理结论是：
$$
\boxed{\beta=1-D_{LK}(p,q)}
$$
其中 $\beta$ 是在当前前缀下，小模型候选被接受的概率。

小模型先采样：
$$
x\sim q(x)
$$

给定候选 \(x\)，接受概率是：
$$
\min\left(1,\frac{p(x)}{q(x)}\right)
$$

所以总体接受率为：
$$
\begin{aligned}
\beta
&=\mathbb E_{x\sim q}
\left[
\min\left(1,\frac{p(x)}{q(x)}\right)
\right]\\
&=\sum_xq(x)
\min\left(1,\frac{p(x)}{q(x)}\right)\\
&=\sum_x\min(p(x),q(x))
\end{aligned}
$$

根据 Lemma 3.3：
$$
\sum_x\min(p(x),q(x))
=1-D_{LK}(p,q)
$$

因此：
$$
\boxed{\beta=1-D_{LK}(p,q)}
$$

含义是：
> 目标模型与小模型的分布越接近，候选接受率越高。

---

### Corollary 3.6：平均接受率 $\alpha$

由于不同前缀下的 $p,q$ 不同，$\beta$ 也会变化。作者定义平均接受率：
$$
\alpha=E(\beta)
$$

把 Theorem 3.5 代入：
$$
\begin{aligned}
\alpha
&=E(\beta)\\
&=E\left[1-D_{LK}(p,q)\right]\\
&=1-E\left[D_{LK}(p,q)\right]
\end{aligned}
$$
因此：
$$
\boxed{
\alpha
=
1-E\left[D_{LK}(p,q)\right]
}
$$

也可以写成：
$$
\boxed{
\alpha
=
E\left[\sum_x\min(p(x),q(x))\right]
}
$$
这里的期望是对实际生成过程中遇到的不同前缀取平均。

### 三者的关系
$$
\boxed{
\begin{aligned}
\text{Lemma 3.3：}\quad
&D_{LK}=1-\text{分布重合量}\\[2mm]
\text{Corollary 3.4：}\quad
&0\le D_{LK}\le1，并给出两个边界情况\\[2mm]
\text{Theorem 3.5：}\quad
&\beta=1-D_{LK}\\[2mm]
\text{Corollary 3.6：}\quad
&\alpha=E(\beta)=1-E(D_{LK})
\end{aligned}
}
$$

最终它把“两个模型有多接近”与“speculative decoding 能接受多少候选”联系起来：
$$
M_q\text{ 越接近 }M_p
\Rightarrow D_{LK}\text{ 越小}
\Rightarrow\beta,\alpha\text{ 越大}
\Rightarrow\text{每轮生成的 token 越多}
$$

$D_{LK}$ 是差异程度，$1-D_{LK}$ 是重合率$\beta$，$\alpha=E(\beta)$是平均接受率，用于计算平均token $E(N)$ 数量。

## 3.3 Walltime Improvement
核心假设：
- 假设拥有足够的计算资源来支持增加的并发性
- 在墙时分析中，我们将假设可以在不增加墙时的情况下，并行运行 γ + 1 次 Mp 的评估。

### Definition 3.7.
设 c 为成本系数，即 Mq 单次运行所需时间与 Mp 单次运行所需时间之比：
$$
c = \frac{T_q}{T_p}
$$
需要注意的是，与作为模型和任务固有属性的α不同，c的值取决于硬件配置和软件实现细节。在我们的实验中，**Mq通常比Mp小几个数量级**，此时**c始终小于0.05，且往往接近0，可忽略不计**。

### Theorem 3.8.
定理 3.8. 算法 1 带来的总墙时预期改进因子为：
$$speedup = \frac{1-\alpha^{\gamma+1}}{(1-\alpha)(\gamma c+1)}$$
speculative decoding 相对于普通自回归解码的期望 walltime加速比

#### 推导过程
1. 普通解码的单位token耗时
设目标模型 $M_p$ 生成一个token所需时间为：$T$
因此普通自回归解码的单位token成本是：$C_{normal} = T$

2. algorithm 1 每轮的耗时
成本系数定义为：$$c=\frac{T_q}{T_p}$$
所以小模型运行一次的时间是：$$T_q=cT$$
为了提出 $\gamma$ 个候选，小模型需要自回归运行 $\gamma$ 次：
$$
T_{draft}=\gamma c T
$$
目标模型对所有候选进行一次并行验证。论文假设计算资源足够，使这次并行验证耗时约为：$$T_{target}=T$$
所以一轮algorithm 1的总耗时为：$$T_{iteration} = \gamma cT+T=(\gamma c+1)T$$

3. 每轮平均生成的token数
根据3.1：$$E(N) = \frac{1-\alpha^{\gamma+1}}{1-\alpha}$$
所以 speculative decoding生成一个token的平均时间为：
$$
\begin{aligned}
C_{\text{spec}}
&=
\frac{\text{每轮耗时}}
{\text{每轮平均生成 token 数}}\\
&=
\frac{(\gamma c+1)T}
{\dfrac{1-\alpha^{\gamma+1}}{1-\alpha}}\\
&=
\frac{(\gamma c+1)(1-\alpha)}
{1-\alpha^{\gamma+1}}T
\end{aligned}
$$

4. 计算加速比
加速比定义为：
$$
\text{Speedup}
=
\frac{\text{普通解码单位 token 耗时}}
{\text{推测解码单位 token 耗时}}
$$
代入：
$$
\begin{aligned}
\text{Speedup}
&=
\frac{T}
{\dfrac{(\gamma c+1)(1-\alpha)}
{1-\alpha^{\gamma+1}}T}\\
&=
\boxed{
\frac{1-\alpha^{\gamma+1}}
{(1-\alpha)(\gamma c+1)}
}
\end{aligned}
$$
也可以写成更直观的形式：
$$
\boxed{
\text{Speedup}
=
\frac{\text{每轮平均生成 token 数}}
{\text{每轮相对时间成本}}
=
\frac{E(N)}{1+\gamma c}
}
$$

数值例子

假设：
$$
\alpha=0.8,\qquad \gamma=4,\qquad c=0.05
$$

每轮平均生成：
$$
E(N)
=
\frac{1-0.8^5}{1-0.8}
=3.3616
$$

每轮相对时间成本：
$$
1+\gamma c
=1+4\times0.05
=1.2
$$

所以：
$$
\text{Speedup}
=
\frac{3.3616}{1.2}
\approx2.80
$$
即理论上约为普通解码的 $2.8$ 倍。

该定理依赖两个关键假设：
- 不同位置的候选接受事件近似独立，平均接受率为 $\alpha$；
- 目标模型对 $\gamma+1$ 个位置的验证可以充分并行，walltime 近似为一次目标模型调用。

请注意，定理 3.8 假设生成的token序列**足够长**（例如，由于我们至少运行一次 Mp，因此改进因子上限由生成的令牌数量决定）。

### Corollary 3.9. 
推论 3.9. 若 $α > c$，则存在某个 $γ$，使得我们能获得改进，且改进因子不小于 $\frac{1+α}{1+c}$。
证明：如果我们有一个$\gamma$得到了提升，则存在任意$0 < \gamma* < \gamma$得到了提升，所以当$\gamma = 1$时，由定理3.8 的加速比公式，能够得到最小加速比：
$$
\frac{1-\alpha^2}{(1-\alpha)(c+1)} = \frac{1+\alpha}{1+c}
$$

## 3.4 算术运算的数量
算法 1 并行执行 γ +1 次 Mp 运算，因此并发算术运算的数量增加了 γ +1 倍。

现在，由于算法 1 每次运行最多产生 γ +1 个令牌，因此算术运算的总次数可能会高于标准解码算法。当我们接受来自 Mq 的样本时，这种并发性的提升是“免费”的，且总运算次数并未增加。

然而，当我们拒绝一个猜测时，计算资源便被浪费了。现在，让我们分析本方法对算术运算总次数的影响。

**定义 3.10.** 设 $\hat c$ 为近似模型 $M_q$ 与目标模型 $M_p$ 每令牌**算术运算次数之比**。
$$
\hat c = \frac{小模型单token运算量}{目标模型单token运算量}
$$

其中：
- $\alpha$：平均接受率；
- $\gamma$：每轮草稿 token 数；
- $\hat c$：小模型生成一个 token 的运算量与目标模型生成一个 token 的运算量之比。

**定理 3.11.** 算法 1 的总运算次数的期望增长因子为 $\frac{(1−α)(γ\hat c+γ+1)}  {1−α^{γ+1}}$ 。
证明：
定义普通解码的运算量
设目标模型生成一个 token 所需的算术运算量为：$\hat T$。
那么普通自回归解码每生成一个 token 的运算量就是：$C_{\text{normal}}=\hat T$。
由因为定义3.10得：小模型生成一个token的运算量为：$\hat c \hat T$

一轮algorithm 1的运算量
小模型串行生成 $\gamma$ 个草稿token，因此运算量为：$C_q=\gamma \hat c \hat T$。
目标模型部分的总运算量为$C_p = (\gamma + 1) \hat T$
因此，一轮 Algorithm 1 的总运算量为：
$$
\begin{aligned}
C_{\text{iteration}}
&=C_q+C_p\\
&=\gamma\hat c\hat T+(\gamma+1)\hat T\\
&=(\gamma\hat c+\gamma+1)\hat T
\end{aligned}
$$


一轮平均生成多少token？
根据 3.1：
$$
E(N)
=
\frac{1-\alpha^{\gamma+1}}{1-\alpha}
$$

所以 speculative decoding 平均生成一个 token 的运算量为：
$$
\begin{aligned}
C_{\text{spec/token}}
&=
\frac{C_{\text{iteration}}}{E(N)}\\
&=
\frac{(\gamma\hat c+\gamma+1)\hat T}
{\dfrac{1-\alpha^{\gamma+1}}{1-\alpha}}\\
&=
\frac{(1-\alpha)(\gamma\hat c+\gamma+1)}
{1-\alpha^{\gamma+1}}\hat T
\end{aligned}
$$

与普通解码比较
普通解码每个 token 的运算量是 $\hat T$，所以运算量增加系数为：
$$
\begin{aligned}
\frac{C_{\text{spec/token}}}{C_{\text{normal}}}
&=
\frac{
\dfrac{(1-\alpha)(\gamma\hat c+\gamma+1)}
{1-\alpha^{\gamma+1}}\hat T
}{\hat T}\\
&=
\boxed{
\frac{(1-\alpha)(\gamma\hat c+\gamma+1)}
{1-\alpha^{\gamma+1}}
}
\end{aligned}
$$

如果 α 较小，则算术运算次数的增加幅度较大；反之亦然。
需要注意的是，对于 Transformer 解码器，算法 1 产生的算术运算总次数（不计 $M_q$ 的连续运行）其上界可由一次相同规模的 Transformer 编码器的运行次数来限定。

与算术运算的总次数不同，采用我们的方法后，内存访问的总次数可能会减少。
解释：普通解码生成这些token，需要大约执行E(N) 次目标模型步骤，因此也需要E(N)轮kv Cache读取。而Speculative Decoding只需一次目标模型并行验证。因此根据公式，读取它们所需的内存访问次数将减少至 $\frac{1−α^{γ+1}} {1−α}$ 倍，也就是每轮平均生成的token数。

## 3.5 Choosing $\gamma$
- Figure 3：研究现实中如何选择最优 $\gamma$，所以使用不同的 c>0。
- Table 1、Figure 4：研究算法本身的“速度—运算量”权衡，所以暂时假设 $c=\hat c=0$。

>[!Tip] 为什么假设$c=\hat c=0$？
>两个参数含义不同：
>$$
>c = \frac{小模型单步耗时}{目标模型单步耗时}
>$$
>$$
>\hat c = \frac{小模型单步运算量}{目标模型单步运算量}
>$$
>令 $c = \hat c = 0$，表示假设草稿模型的时间和运算成本是可以忽略的。目的是排除小模型自身影响，单独观察：$\alpha$（候选接受率）和$\gamma$（候选数量）是如何影响速度和目标模型的无效计算。
>
> 令$c=0$，由定理3.8得：$$S = \frac{1 - \alpha^{\gamma+1}}{1-\alpha} = E(N)$$，即加速比直接等于每轮平均生成的token数
> 令$\hat c = 0$，由定理3.11得：$$O = \frac{(1−α)(γ\hat c+γ+1)}  {1−α^{γ+1}} = \frac{(1+\gamma)}{E(N)}$$，虽然忽略了小模型运算量，目标模型仍然计算了$\gamma+1$个位置。因此，如果候选被拒绝，仍会由目标模型计算被浪费。

### Figure 3
给定 c 和 α，并假设计算资源充足，最优的 γ 是**使墙时改进方程达到最大值的那个值**。由于 γ 是整数，因此可以很容易地通过数值计算求得，参见图 3。
![[Pasted image 20260916092740.png]]
规律一：$\alpha$ 越高，最优 $\gamma$ 越大

规律二：$c$ 越高，最优 $\gamma$ 越小

### Table1 + Figure4
![[Pasted image 20260916095524.png]]
虽然加速比增大，但是运算操作也增多。

![[Pasted image 20260916095539.png]]
- 随着 $\alpha$ 增大，速度越快，计算浪费更少
- 随着 $\gamma$ 增大，潜在速度更高，单低接受率时浪费更多

## 3.6 近似模型
### 1. 现成的小型trasnformer
- 与目标模型相同的架构
- 相同的tokenizer
- 相同的probability standardization，例如相同temperature、top-k等

- 草稿模型比目标模型大小约两个数量级时通常效果较好

- 需要平衡：接受率 $\alpha$ 与 草稿成本 $c$
	- 草稿模型太小：速度快、c小，但预测较差、$\alpha$低
	- 草稿模型太大：预测准确、$\alpha$高，但自身运行慢、c大
### 2. 近似零成本的 n-gram 模型
n-gram是传统语言模型：只根据前面最近的n-1个token，预测下一个token。
其基本假设是：
$$
P(x_t|x_1,...,x_{t-1}) ≈ P(x_t|x_{t-n+1}, ..., x_{t-1})
$$
### 3. 基于上下文复制的启发式方法

### 4. 非自回归模型

### 5. 随机draft model

# 4. Experiments
## 4.1 实测墙时提升
### 实验设置

目标模型统一使用：$M_p=\text{T5-XXL 11B}$

测试两个任务：
- **EnDe**：WMT 英语到德语翻译；
- **CNN/DM**：新闻文本摘要。

Draft model 使用同系列的三个现成模型：

| Draft model | 参数量 |
|---|---:|
| T5-small | 77M |
| T5-base | 250M |
| T5-large | 800M |

实验环境：
- 单张 TPU-v4；
- batch size 为 1；
- 与优化过的 T5X 普通解码实现比较；
- 使用现有 checkpoint，不额外训练 draft model。

测试两种采样设置：
- $T=0$：argmax/greedy decoding；
- $T=1$：标准随机采样。

表中的字段含义是：

- `TEMP`：温度设置；
- $\gamma$：每轮 draft token 数；
- $\alpha$：平均接受率；
- `SPEED`：相对于普通 T5X 解码的 walltime 加速倍数。

#### 翻译任务结果

##### T=0：贪心解码

| Draft model | \(\gamma\) | \(\alpha\) |       加速 |
| ----------- | ---------: | ---------: | -------: |
| T5-small    |          7 |       0.75 | **3.4×** |
| T5-base     |          7 |       0.80 |     2.8× |
| T5-large    |          7 |       0.82 |     1.7× |

随着 draft model 增大：
$\alpha:0.75\rightarrow0.80\rightarrow0.82$

接受率确实提高了，但速度反而下降：
$3.4\times\rightarrow2.8\times\rightarrow1.7\times$

因为更大的 draft model 虽然预测更准，却具有更高的成本 $c$。

##### T=1：随机采样

| Draft model | \(\gamma\) | \(\alpha\) | 加速 |
|---|---:|---:|---:|
| T5-small | 7 | 0.62 | **2.6×** |
| T5-base | 5 | 0.68 | 2.4× |
| T5-large | 3 | 0.71 | 1.4× |
随机采样下接受率降低，整体加速也低于贪心解码。

#### 摘要任务结果

##### T=0

| Draft model | \(\gamma\) | \(\alpha\) | 加速 |
|---|---:|---:|---:|
| T5-small | 5 | 0.65 | **3.1×** |
| T5-base | 5 | 0.73 | 3.0× |
| T5-large | 3 | 0.74 | 2.2× |
##### T=1

| Draft model | \(\gamma\) | \(\alpha\) | 加速 |
|---|---:|---:|---:|
| T5-small | 5 | 0.53 | **2.3×** |
| T5-base | 3 | 0.55 | 2.2× |
| T5-large | 3 | 0.56 | 1.7× |
摘要任务的接受率整体低于翻译任务，说明摘要生成更加开放，draft model 与目标模型更容易产生不同选择。

### 4.1 的主要结论

#### 结论一：最准确的 draft model 不一定最快

T5-large 的 \(\alpha\) 最高，但加速通常最低。真正决定速度的是：
$$
\text{Speedup}
=
\frac{1-\alpha^{\gamma+1}}
{(1-\alpha)(1+\gamma c)}
$$
因此需要同时考虑：
- $\alpha$：预测准确度带来的收益；
- $c$：运行 draft model 的成本。
T5-small 在两者之间取得了最佳平衡。

#### 结论二：贪心解码通常更容易加速
在 $T=0$ 时，调整后的分布非常尖锐，通常只有 argmax token 的概率为 1。如果两个模型选择相同的 argmax，候选就能直接接受。

随机采样的分布更分散，小模型与目标模型的采样结果更容易不同，所以 $\alpha$ 较低。

实验中：
- 翻译：$3.4\times$（$T=0$）和 $2.6\times$（$T=1$）；
- 摘要：$3.1\times$（$T=0$）和 $2.3\times$（$T=1$）。

#### 结论三：实测结果总体符合理论

作者在附录 A.3 中用实测的 $\alpha,c,\gamma$ 代入定理 3.8，理论值与实测速度总体接近。

差异主要来自：
- 实现和基线的优化程度不同；
- 不同位置的 $\beta$ 并非真正独立同分布；
- 硬件并行并不完全符合理论假设。

### 4.2 Empirical $\alpha$ Values

这一节不再完整实现 walltime 测试，而是测量各种组合下的平均接受率：
$$
\alpha=E(\beta)
$$

每组设置使用目标模型生成的 10,000 个 token 进行估计。

#### 第一组：GPT-like 97M

任务：
- LM1B 上的无条件文本生成。

目标模型：
$$
M_p=\text{GPT-like 97M}
$$

Draft model：
- unigram；
- bigram；
- GPT-like 6M。

主要结果：

| Draft model | \(T=0\) 的 \(\alpha\) | \(T=1\) 的 \(\alpha\) |
|---|---:|---:|
| Unigram | 0.03 | 0.03 |
| Bigram | 0.05 | 0.05 |
| GPT-like 6M | 0.88 | 0.89 |
6M 参数的小型 Transformer 与 97M 目标模型非常接近，接受率约为 0.9。Unigram、bigram 成本极低，但在开放式生成上的接受率很低。

#### 第二组：T5-XXL 11B

测试任务仍然是：
- 英德翻译；
- CNN/DM 摘要。

结果显示：
- T5-small、base、large 的 $\alpha$ 大致为 $0.5\sim0.82$；
- draft model 越大，$\alpha$ 越高；
- 翻译任务的 $\alpha$ 通常高于摘要任务；
- $T=0$ 的 $\alpha$ 通常高于 $T=1$。

值得注意的是，简单 bigram 在英德翻译上也得到：
$$
\alpha\approx0.2
$$

因为 bigram 基本是查表，可认为：
$$
c\approx0
$$

取 $\gamma=3$ 时仍能获得约 $1.25\times$ 加速。

这说明：
> Draft model 不一定必须是神经网络；只要成本足够低，即使接受率不高，也可能有收益。

#### 第三组：LaMDA 137B

任务：
- 对话生成。

目标模型：
$$
M_p=\text{LaMDA 137B}
$$

Draft model：
- LaMDA 100M；
- LaMDA 2B；
- LaMDA 8B。

结果：

| Draft model | \(T=0\) 的 \(\alpha\) | \(T=1\) 的 \(\alpha\) |
|---|---:|---:|
| LaMDA 100M | 0.61 | 0.57 |
| LaMDA 2B | 0.71 | 0.71 |
| LaMDA 8B | 0.75 | 0.74 |

Draft model 越大，接受率越高。但这里作者只测量了 $\alpha$，没有报告完整的 LaMDA walltime 加速。

## Section 4 的整体结论

实验支持了以下观点：

1. **Speculative decoding 可以获得真实 walltime 加速。**  
   在 T5-XXL 上达到约 $2\sim3\times$，最佳结果为 $3.4\times$。

2. **Draft model 不是越大越好。**  
   更大模型提高 $\alpha$，但也提高 $c$。T5-small 比 T5-base、T5-large 更快。

3. **任务决定接受率。**  
   **确定性较强的翻译任务**比**开放式摘要**更容易获得较高接受率。

4. **采样方式影响接受率。**  
   贪心解码的分布更尖锐，通常比随机采样获得更高的 $\alpha$ 和加速比。

5. **简单模型也可能有价值。**  
   n-gram 即使接受率较低，只要成本接近零，也可能提供一定加速。

6. **理论公式具有一定预测能力。**  
   定理 3.8 根据 $\alpha,c,\gamma$ 预测的加速比与实际结果总体吻合。

最重要的实验结论可以概括成：
$$
\boxed{
\text{最佳 draft model}
\neq
\text{接受率最高的模型}
}
$$

而是：
$$
\boxed{
\text{能够在较高 }\alpha
\text{ 和较低 }c
\text{ 之间取得最佳平衡的模型}
}
$$