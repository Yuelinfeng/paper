# 1. 概念映射

| CFM对象              | vLLM视角                        |
| ------------------ | ----------------------------- |
| view               | 需要执行的prefill输入                |
| view feature       | 生成后的KV状态                      |
| pair               | 等待执行的请求                       |
| feature slab       | KV cache block                |
| Pair Scheduler     | Continuous batching scheduler |
| Matcher            | 批量执行引擎                        |
| FrontierCacheState | KV block manager              |
| pair completion    | 请求完成事件                        |
> CFM真正被调度执行的是pair，但pair能否执行取决于两个共享view feature是否驻留。
> 因此它不是普通请求队列，而是带共享依赖的请求调度。

## 总体抽象
把 CFM 看成一个类似LLM Serving的在线执行系统：
```
Workload
	↓
Planner
	↓
Scheduler
	↓
Cache Manager
	↓
GPU Executor
	↓
Completion / Resource Reclaim
```

在CFM中对应为：
```
共视图与 pairs
	↓
规划view顺序
	↓
选择ready pairs
	↓
管理 feature pairs
	↓
Feature / Matcher 异步执行
	↓
完成回调与 slab 回收
```

vLLM调度的是请求；CFM调度的是pair
```
PairRequest {
	original_index
	endpoint_a
	endpoint_b
	state
}
```
但是pair不是独立任务，它依赖两个共享资源：
```
Pair(A, B) 可执行 <＝> Feature(A) resident && Feature(B) resident
```
因此，CFM可以抽象为：带共享缓存依赖的批处理请求系统。

# 二、资源类型
在vLLM中，核心稀缺资源是KV Cache block；在CFM中则是Feature Cache slab
```
vLLM:
request -> KV blocks

CFM:
view -> feature slot
多个slot -> slab
多个pairs -> 共享view feature
```

真实实现中，`FrontierCacheState` 负责维护：
```
view -> physical_slot
view -> generation
view -> remaining_edges
logical_slab -> physical_slab
free_physical_slabs
```
这相当于CFM版本的KV Cache Manager

# 三、调度器的核心决策
每轮调度实际上回答三个问题：
```
1. 现在还能不能生产新的view feature？
2. 哪些pair已经ready，可以组成 Matcher batch？
3. 哪些 slab 已经没有消费者，可以回收？
```

可以抽象为：
```
while (!finished) {
	update_comleted_requests();
	reclaim_unused_cache();
	
	discover_ready_requests();
	
	if (matcher_budget_available()) {
		schedule_ready_pairs();
	}
	
	if (cache_budget_available()) {
		schedule_next_view_batch();
	} else {
		apply_backpressure();
	}
}
```

这与vLLM的调度循环十分相似：
```
更新完成请求
-> 回收 KV blocks
-> 检查 token/block budget
-> 选择 waiting/running requests
-> 形成下一批执行计划
```

# 四、离线规划与在线调度
CFM 比 vLLM多一个重要层次：图拓扑规划。

## 离线 Planner
提前决定 view 的生产顺序：
```
Pair Graph
-> BFS / RCM / Min-Frontier 候选
-> 模拟 resident 生命周期
-> 选择显存峰值较低的顺序
```
它解决的是：怎样安排feature的产生顺序，才能让旧feature尽快完成全部消费并释放？

## 在线Scheduler
运行时根据真实状态决定：
```
继续提取
或
提交 Matcher
或
等待完成
或
回收slab
```
因此整体是：
```
离线优化未来资源生命周期
+
在线根据实际完成情况进行流量控制
```

# 五、Continuous Batching
CFM借鉴vLLM的关键思想不是"动态batch"本身，而是：
> 局部条件满足后立即推进，不等待全局阶段完成。

传统方式：
```
全部 Feature 完成
-> 全部 Matcher 开始
```

Frontier方式：
```
某个 pair 两端 ready
-> 进入ready queue
-> 达到batch/trigger条件
-> 立即匹配
```

> [!Note] 两端是什么意思
> 两端是指：
> ```
> 图像A —— pair —— 图像B
 > 端点1            端点2
> ```
> 某个pair两端 ready就是：
> 图像A 和 图像B 的特征都已提取完成，并且仍驻留在GPU Feature Cache中，此时 Matcher 才能执行 A <-> B 的特征匹配。
> 
> 形式化表达为：`Pair(A, B) 可执行 <＝> Feature(A) resident && Feature(B) resident`
> 
> 可以类比vLLM：一个计算任务依赖的KV Cache blocks都已准备好并驻留，任务才具备被调度执行的条件。

真实参数包括：
```
trigger_pairs = 64
batch_pairs = 4
max_inflight_batches = 16
```
分别对应首批启动门槛、单批大小和执行预算。

# 六、背压思想
vLLM 在 KV block不足时暂停admission或执行抢占；CFM采用高低水位drain：
```
resident >= high_watermark
-> 暂停生产新 feature
-> 消费 ready pairs
-> 回收 slab
-> resident <= low_watermark
-> 恢复生产
```
这里使用迟滞区间：
```
low = 896 = 7x128
high = 1152 = 9x128
capacity = 1280 = 10x128

满足显存安全、调度可排布、背压稳定和性能验证的一组已测试参数。
```
这样可以避免生产者在单一阈值附近频繁启停。

# 七、资源释放原则
CFM中的feature类似共享KV block，不能由单个pair独占释放。
```
remaining_edges(view)
	每完成一个关联 pair：-1
	降为 0: view 不再被使用
```

但实际分配单位是slab，因此：
```
slab中所有view的remaining_edges 都为 0
```
复用时递增 generation。异步任务完成后必须验证：
```
提交时 generation == 完成时 generation
```
否则说明发生了提前覆盖，必须fail-closed。

> [!Tip] `generation` 是缓存槽位的版本号，用来检测该槽位是否在异步任务完成前被错误覆盖或复用。

# 八、后续统一表达结构
之后每个主题都按以下格式展开：
- vLLM中的调度问题
- 抽象出通用调度思想
- 映射到CFM后发生的变化
- CFM的逻辑实现
- 对应真实类和关键状态
- 正确性、性能与失败边界
核心主线是：
```
请求状态机
-> 资源预算
-> Continuous Batching
-> Cache 生命周期
-> 背压
-> 完成反馈
-> 下一轮调度
```
这样学习的最终结果不是记住CFM的若干参数，而是掌握一种可迁移到LLM Serving、图任务和异构流水线中的调度设计方法。
