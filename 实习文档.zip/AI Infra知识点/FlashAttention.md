# 1. 在LLM背景下，FlashAttention是什么
标准Attention的数学形式是：
$$O=\operatorname{Softmax}\left(\frac{QK^T}{\sqrt{D}}\right)V$$
其中，若序列长度为$T$，注意力分数矩阵$QK^T$的形状是$[T,T]$。

普通实现通常是：
```
Q、K、V
	-> 计算 score = QK^T #[T,T]
	-> 将 score 写回显存  
	-> Softmax(score)    #[T,T]
	-> 再写回显存
	-> probability x V
```
问题不在于Attention的数学计算本身，而在于中间的$[T,T]$矩阵很大，频繁写入、读取GPU显存。对LLM的长上下文prefill而言，这成为明显的显存和带宽瓶颈。

FlashAttention的核心思想是：
```
将Q分块
	-> 逐块读取K/V
	-> 在GPU片上存储完成QK^T、Softmax、乘V
	-> 使用online Softmax累积结果
	-> 不物化完整[T,T]分数/概率矩阵
```
因此它：
- 不改变Attention的语义
- 不把Attention的算术复杂度从$O(T^2D)$变成线性
- 主要减少$O(T^2)$中间矩阵的显存占用与显存读写
- 通常显著改善长序列Attention的吞吐和延迟

