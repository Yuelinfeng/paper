**整体链路概览：** loma-b用BF16保住数值稳定性；在SM89上靠**FlashAttention**、**FFN融合**和*早期token pruning*取得主要加速；SM80/90 则采用更通用、稳妥的 cuDNN BF16 路径。
# 三种GPU的实际路径

| GPU  | loma-b route   | Attention                  | FFN            | token数           |
| ---- | -------------- | -------------------------- | -------------- | ---------------- |
| SM80 | bf16-portable  | cuDNN BF16 SDPA            | Exact BF16     | 保持完整             |
| SM89 | bf16-prune1024 | **PyTorch FlashAttention** | **Fused BF16** | 第二层后2048 -> 1024 |
| SM90 | bf16-portable  | cuDNN BF16 SDPA            | Exact BF16     | 保持完整             |
# 编译期

| 编译期操作                            | LLM推理意义                           |
| -------------------------------- | --------------------------------- |
| 为SM80、SM89、SM90生成对应CUDA机器码       | 避免运行时JIT或不匹配架构导致的低效回退             |
| 为Torch设置相同的GPU架构目标               | 让PyTorch CUDA部分与项目自身CUDA kernel一致 |
| 编译通用QKV/RoPE、布局处理、过滤等CUDA Kernel | 这些是所有BF16路径可复用的基础优化               |
| SM89使用对应的BF16 FlashAttention能力   | 让Attention使用更适合长序列的fused kernel   |
# 每层Transformer的优化链
可将LLM/Transformer的一层抽象为：
```
输入状态
	-> Linear生成QKV
	-> RoPE
	-> Self-Attention / Cross-Attention
	-> 输出投影 + residual
	-> LayerNorm + GELU + FFN
```

loma-b对这条链做的优化如下：

| 位置        | 优化                                     | LLM推理意义                                 |
| --------- | -------------------------------------- | --------------------------------------- |
| 双序列输入     | 尽量合并为batch=2                           | 两路状态并行计算，提高Tensor Core利用率               |
| 数据准备      | 内存连续时使用零拷贝视图                           | 避免为了拼batch额外复制Tensor                    |
| QKV+RoPE  | 一个CUDA kernel完成Q/K/V拆分、RoPE、目标布局写出     | 少中间Tensor、少显存读写、少kernel launch          |
| Attention | SM89用FlashAttention；SM80/90用cuDNN SDPA | 避免显式物化完整 $T \times T$ attention score矩阵 |
| FFN       | SM89把LayerNorm、affine、精确GELU、BF16输出合并  | 减少FFN中间激活的写回与重新读取                       |
| 固定带宽FFN   | 对512/1024宽度使用专门CUDA kernel             | 使用寄存器和warp shuffle，减少线程同步               |
| 最终过滤      | CPU内完成规约、argmax、阈值等后处理                 | 避免大结果Tensor回传CPU                        |
# FlashAttention
loma-b在SM89上使用的是PyTorch内置的BF16 FlashAttention后端。loma-b自己不实现flash attention 主计算kernel；它负责把Q/K/V准备成PyTorch所需格式，并调用ATen的FlashAttention算子。

## loma-b为什么需要FlashAttention
虽然 LoMa-B 不是自回归 LLM，但它的 Matcher 内部同样是 Transformer Attention：**输入序列经过 Q/K/V 投影后，进行 Self-Attention 和 Cross-Attention**。

从通用 Transformer 推理角度，它面对的问题是：
```text
序列较长
	+ 每层都有 Self-Attention
	+ 还需要 Cross-Attention
	+ BF16 Tensor Core 已经较快
→ Attention 中间矩阵的显存读写变得突出
```

在 SM89 的 LoMa-B 路径中，初始 token 数是 2048。即使不考虑任何具体业务，单个 head 的 score 矩阵也是：
```text
2048 × 2048 = 4,194,304 个元素
```
多 head、多层、Self/Cross Attention 叠加后，若使用普通的分步实现，显存流量会很高。

因此 LoMa-B 在 SM89 上采用 FlashAttention：**避免显式保存完整 Attention matrix，让 Attention 计算更多在 kernel 内完成。**
## LoMa-B 用的是哪一种 FlashAttention
LoMa-B 使用的是 **PyTorch 内置的 FlashAttention SDPA 后端**，不是仓库自行编写的 BF16 FlashAttention。

代码直接调用：
```cpp
at::_scaled_dot_product_flash_attention(
    query, key, value,
    0.0,       // dropout
    false,     // 非 causal
    false,     // 不要 debug mask
    1 / sqrt(head_dim));
```

运行链为：
```text
LoMa-B 准备 Q/K/V
→ 调用 PyTorch ATen FlashAttention 接口
→ PyTorch libtorch_cuda.so 中的 BF16 FlashAttention kernel
→ 返回 context
→ LoMa-B 再做 output projection / FFN
```
所以可以理解为：**LoMa-B 调用 PyTorch 的成熟 FlashAttention 实现，而不是自己维护 Attention 主 kernel。**

## 为什么使用 PyTorch 自带实现，而不是自定义 FlashAttention

原因不是“自定义做不到”，而是 LoMa-B 当前 BF16 路径没有足够理由承担自定义 Attention kernel 的成本。

| 对比点 | 使用 PyTorch 内置 FlashAttention | 自定义 FlashAttention |
|---|---|---|
| 核心 kernel | 使用成熟实现 | 需要自行写、调优、验证 |
| BF16 与 Tensor Core | 已处理 | 需自行适配 |
| 不同 head_dim / shape | PyTorch 内部已选择相应 kernel | 需要维护大量模板和 dispatch |
| 数值稳定性 | 已有成熟的 online Softmax 实现 | 需大量精度验证 |
| CUDA/PyTorch 版本兼容 | 由 PyTorch 负责 | 自己承担 ABI、编译器、CUDA 兼容风险 |
| 维护成本 | 低 | 高 |
| LoMa-B 当前需求 | BF16、标准非 causal Attention | 不需要为此专门重写主 kernel |

LoMa-B 的策略是把“最适合业务模型结构的部分”留给自己优化：
```text
QKV 拆分
+ RoPE
+ A/B batch=2 合并
+ Cross-Attention 的 K/V 交换与打包
+ 避免无意义 copy
```

而将最复杂、最成熟的 Attention 主计算交给 PyTorch。

## LoMa-B 在调用 FlashAttention 前做了什么
FlashAttention 并不能直接吃任意形状的 Q/K/V。LoMa-B 先把 Transformer 层的输出整理为适合 Attention 的布局。

普通逻辑是：
```python
qkv = linear(x, Wqkv)        # [T, 3E]

q, k, v = split(qkv)         # 三个 Tensor
q = rope(q)
k = rope(k)
q = reshape_layout(q)
k = reshape_layout(k)
v = reshape_layout(v)

context = flash_attention(q, k, v)
```

LoMa-B 将中间步骤融合为一个 CUDA kernel：
```python
qkv = linear(x, Wqkv)        # [T, 3E]

q, k, v = fused_qkv_rope_layout(
    qkv,
    cosine,
    sine,
    output_layout="[B, H, T, D]"
)

context = torch_flash_attention(q, k, v)
```

这个 LoMa-B 自定义 kernel 一次完成：
1. 从交错 QKV 输出中拆出 Q、K、V；
2. 对 Q、K 应用 RoPE；
3. 将三者直接写为 FlashAttention 所需的 `[B, H, T, D]` 布局；
4. 避免额外的切分、RoPE 和 `permute().contiguous()` 操作。

## Self-Attention 中如何使用

逻辑可以抽象为：
```python
def self_attention(x, Wqkv, rope):
    # BF16 Linear，生成 [T, 3E]
    qkv = linear(x, Wqkv)

    # LoMa-B 自定义融合准备
    q, k, v = fused_qkv_rope_layout(
        qkv, rope.cos, rope.sin,
        layout="BHSD"           # [1, H, T, D]
    )

    # PyTorch 内置 FlashAttention
    context = flash_attention(
        q, k, v,
        dropout_p=0.0,
        is_causal=False,
        scale=1 / sqrt(D)
    )

    # [1, H, T, D] → [T, E]
    return context.permute(0, 2, 1, 3).reshape(T, E)
```
这里 `is_causal=False` 很重要：它与标准 Decoder LLM 的 causal self-attention 不同。LoMa-B 的 Attention 没有“当前位置只能看过去 token”的下三角限制。

## Cross-Attention 中如何使用

Cross-Attention 需要计算两个方向：
```text
A 读取 B：Q=A，K=B，V=B
B 读取 A：Q=B，K=A，V=A
```

最直接的写法是两次 FlashAttention：
```python
out_a = flash_attention(q_a, k_b, v_b)
out_b = flash_attention(q_b, k_a, v_a)
```

LoMa-B 尽量将其合为一次 batch=2 调用：
```python
def paired_cross_attention(q_a, v_a, q_b, v_b):
    # batch 0: A 读取 B
    # batch 1: B 读取 A
    Q = [q_a, q_b]
    K = [q_b, q_a]
    V = [v_b, v_a]

    context = flash_attention(
        Q, K, V,               # [2, H, T, D]
        dropout_p=0.0,
        is_causal=False,
        scale=1 / sqrt(D)
    )

    return context[0], context[1]
```

一个额外优化是：若 A/B 的 Q 已经在同一块连续显存中，LoMa-B 用 `as_strided` 将其直接解释为 batch=2，不再复制 Q；只为必须交换方向的 K/V 执行打包。

## 8. 使用后的效果
从 LLM 推理视角，效果分为三个层次。

| 层次            | FlashAttention / LoMa-B 布局优化带来的效果                  |
| ------------- | -------------------------------------------------- |
| Attention 主计算 | 不物化完整 `[T, T]` score/probability 矩阵，降低显存占用和 HBM 读写 |
| 输入准备          | QKV 拆分、RoPE、布局转换合并，减少临时 Tensor 和 kernel launch     |
| 双路 Attention  | A/B 合并为 batch=2，减少两次独立调用的调度与数据准备开销，提高 GPU 利用率      |

因此整体效果不是“Attention 从二次复杂度变成线性”，而是：
```text
保留原本 Attention 的计算语义
+ 保留二次 token 两两交互
- 移除大规模中间矩阵物化
- 减少 QKV 前后处理的显存搬运
- 在可能时将两路 Attention 合为一个 batch=2 调用
```

# Kernel Fusion
loma-b默认的BF16 Matcher路径：把本来会分开执行、并在显存间反复读写的数据处理步骤，尽量放进一次GPU kernel或一次GEMM epilogue中完成。

先区分三个概念：

| 概念                   | 含义                          | loma-b中的例子                  |
| -------------------- | --------------------------- | --------------------------- |
| 真正的kernel fusion     | 多个计算步骤由一个CUDA kernel完成      | QKV拆分+RoPE+布局写入             |
| GEMM epilogue fusion | 矩阵乘法结束时顺带完成bias / residual等 | Linear3+bias+residual       |
| batch=2 合批           | A/B两路数据一起算，不一定是一个kernel     | A/B一起做FlashAttention或Linear |
后两者都能加速，但严格来说，只有第一类一定是“多个算子融合成一个CUDA kernel”

## 每层适合融合的地方
把一层抽象成：
```
Self-Attention:X -> QKV Linear -> QKV拆分 -> RoPE -> Attention -> output Linear

FFN:
residual X + attention message
-> concat
-> Linear0
-> LayerNorm
-> GELU
-> Linear3
-> residual add
```
其中最容易浪费时间的不是大GEMM本身，而是GEMM前后的：
- 切分/拼接
- 转置和layout copy
- LayerNorm的中间结果
- GELU的中间结果
- residual add
- A/B 双路独立处理
loma-b的融合主要覆盖这些“外围小算子”
```mermaid
flowchart LR
  X[输入状态] --> QKV[QKV Linear]
  QKV --> F1[融合1：拆分 QKV + RoPE + Flash 布局]
  F1 --> ATTN[FlashAttention]
  ATTN --> OP[输出 Linear]
  X --> CAT[融合2：A/B FP32 state + BF16 message 拼接]
  OP --> CAT
  CAT --> L0[FFN Linear0]
  L0 --> F2[融合3：LayerNorm + affine + GELU + BF16 cast]
  F2 --> L3[FFN Linear3]
  L3 --> F3[融合4：FP32 residual + BF16 projection]
```

## 融合1：QKV拆分、RoPE与Attention布局融合
这是loma-b中最标准、最重要的kernel fusion
普通实现：
```
qkv = linear(x, Wqkv)                    # [T, 3E]
q, k, v = split(qkv, 3, dim=-1)          # 三份逻辑Tensor
q = apply_rope(q, cos, sin)
k = apply_rope(k, cos, sin)

q = q.reshape(T, H, D).permute(1, 0, 2)  # 准备 Flash layout
k = k.reshape(T, H, D).permute(1, 0, 2)
v = v.reshape(T, H, D).permute(1, 0, 2)
```
这会带来多次遍历和可能的连续化拷贝。

loma-b 将它变为：
```
qkv = linear(x, Wqkv)

q, k, v = fused_qkv_rope_layout(
	qkv, cos, sin, output_layout="[B, H, T, D]"
)
```

一个CUDA Kernel 内完成：
```
读取交错的QKV
-> 拆出Q、K、V
-> 对Q和K做RoPE
-> V原样保留
-> 直接写到FlashAttention所需的BHSD布局
```
主要减少的是：
```
Q/K/V中间Tensor
+ RoPE的单独kernel
+ permute后可能产生的 contiguous copy
+ 多次读写 Q/K/V
```
- FlashAttention只负责之后的Attention主计算；
- 这个融合kernel是loma-b为喂给FA所做的前处理优化

## FFN: LayerNorm + affine + 精确GELU + BF16 写回融合
这是loma-b FFN中另一个真正的融合点。

常规FFN中，`Linear0` 后的计算可写作:
```
hidden = linear0(ffn_input)                    #BF16

normalized = layer_norm(hidden.float(), ...)   #FP32
activated = gelu(normalized, approximate="none")
linear3_input = activated.to(bfloat16)
```
若拆开，至少涉及：
```
BF16->FP32
LayerNorm
affine
GELU
FP32->BF16
```
loma-b合并成一个kernel：
```
def fused_norm_gelu_bf16(hidden, gamma, beta,eps):
	for each token row:
		# 1. FP32求均值和方差
		mean, variance = welford_reduce(hidden)
		
		# 2. LayerNorm + affine
		y = (hidden - mean) / sqrt(variance + eps)
		y = y * gamma + beta
		
		# 3. 精确 GELU
		y = 0.5 * y * (1 + erf(y / sqrt(2)))
		
		# 4. 输出BF16
		return bf16(y)
```
该版本的进一步优化是：
```
每个block对应一个token行
每个线程读取两个元素
FP32 Welford 统计保证 LayerNorm 稳定性
后半段归约改用 warp shuffle
减少 shared memory 和 __syncthreads()
```
因此它同时做到:
- 保留LayerNorm / GELU 的关键FP32数值计算
- 避免中间FP32 Tensor落到显存
- 针对固定宽度512减少同步

### A/B FFN 输入拼接 与 BF16 转换
loma-b有一个额外特点：残差状态可以是FP32，而Attention message是BF16。FFN的Linear0需要两者拼接：$$FFNInput = [state, message]$$
普通 A/B双路写法：
```
ffn_a = cat([state_a.to(bf16), message_a], dim=-1)
ffn_b = cat([state_b.to(bf16), message_b], dim=-1)

hidden_a = linear0(ffn_a)
hidden_b = linear0(ffn_b)
```
loma-b改为一个kernel直接形成batch=2的linear0输入：
```
def fused_mixed_concat(state_a_fp32, message_a_bf16,
                       state_b_fp32, message_b_bf16):
    for side in [A, B]:
        out[side, :, :E] = bf16(state[side])   # 转 BF16
        out[side, :, E:] = message[side]       # 直接拷贝
    return out  # [2T, 2E]
```
收益是：
`两个cat + 两次 FP32->BF16 + 两套 A/B Linear0 调度` 变成了 `一次融合pack + 一次 batch=2 Linear0`

这里要准确说：拼接与转换本身融合了；Linear0没有融入同一个自定义CUDA kernel，而是作为后续的高效GEMM单独执行
```
第一步：自定义融合kernel
FP32 state + BF16 message
-> state 转 BF16
-> 按 [state | message] 拼接
-> 同时整理 A/B 两路为 batch=2 输入

第二步：独立的Linear0 GEMM
[2T, 2E] x W_linear0^T
-> [2T, 512]

伪代码:
# 第1步：一个自定义CUDA Kernel
ffn_input_ab = fused_cast_concat(
	state_a_fp32, message_a_bf16,
	state_b_fp32, message_b_bf16
) # [2T, 2E], BF16
# 第2步：独立GEMM
hidden_ab = torch_linear(ffn_input_ab, linear0_weight, linear0_bias)
```
这样做的原因是：拼接/类型转换适合自定义轻量kernel；大矩阵乘法交给成熟GEMM库通常更可靠、性能也更好。真正把`cast+concat+GEMM`完全融合成一个kernel会更激进，但当前loma-b没有这么做

## 总结
### 融合位置及总览

| 融合位置             | 融合内容                                                                                       | 作用                                                                                                           |
| ---------------- | ------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------ |
| F1：Attention 前处理 | `QKV` 拆分 + 对 Q/K 应用 RoPE + 直接写成 FlashAttention 所需的 `[B,H,T,D]` 布局                          | 避免分别切分 Q/K/V、单独执行 RoPE、再做 layout 转换与连续化拷贝；减少中间 Tensor、显存读写和 kernel launch。                                   |
| CAT：FFN 输入准备     | A/B 两路的 FP32 state 转 BF16 + 各自与 BF16 attention message 拼接 + 写成 batch=2 的 `[2T, 2E]` FFN 输入 | 避免两次独立的类型转换与 `cat`；让后续 `Linear0` 可以一次处理 A/B 两路。Linear0 GEMM 本身仍是下一步独立执行。                                     |
| F2：FFN 非线性段      | `LayerNorm` 的 FP32 均值/方差统计 + 归一化 + affine（\(\gamma,\beta\)）+ 精确 GELU + 写回 BF16             | 不需要将 LayerNorm 输出、affine 输出、GELU 输出分别落到显存；保留关键计算的 FP32 稳定性，同时减少中间激活和同步。                                      |
| F3：FFN 残差段       | FP32 residual state + BF16 Linear3 projection → FP32 输出；A/B 两路在同一 kernel 中处理               | 避免为 A/B 分别发射 residual-add kernel；每线程以向量化方式读取 BF16 projection、转 FP32 后加到残差流。这里 Linear3 GEMM 不在同一自定义 kernel 内。 |
### LLM吸收部分

最符合通用 LLM 推理优化思路的是 **F1、F2，以及 FlashAttention 本身**。

| 优先级 | 部分 | 为什么对 LLM 最重要 |
|---:|---|---|
| 1 | FlashAttention | 解决长上下文 Attention 的显存读写瓶颈；不物化完整 \(T \times T\) Attention 矩阵，是主流 LLM prefill 优化。 |
| 2 | F1：QKV 拆分 + RoPE + Attention 布局 | 几乎所有带 RoPE 的 LLM 都需要 QKV、RoPE 和 Attention layout；融合可减少 Q/K/V 的中间 Tensor、转置和显存复制。 |
| 3 | F2：LayerNorm + affine + GELU + cast | LLM 每层都有 Norm 和 MLP 激活；将这些逐元素/归约算子融合是典型的推理 kernel 优化。实际 LLM 中更常见的是 RMSNorm + SiLU/SwiGLU，而非 LayerNorm + GELU。 |

~~F3 也属于通用 LLM 技术，但重要性略低：~~
```text
Linear output + residual add
```

~~这是常见的 GEMM epilogue fusion。通常应尽量并入 GEMM 的 epilogue，例如：~~
```python
y = x @ W.T + bias + residual
```
~~它能减少一次对 Linear 输出的写回与读取。~~

~~CAT 则不适合作为通用 LLM 的首要学习重点：~~
```text
A/B FP32 state + BF16 message 拼接
```
~~它依赖 LoMa-B 的双路状态结构和特定 FFN 输入形式。通用 LLM 的 MLP 往往是：~~
```text
x
→ gate_proj / up_proj
→ SiLU(xWg) ⊙ (xWu)
→ down_proj
→ residual
```
~~没有同样的 `[state | message]` 拼接，因此不能直接复用。~~

可以把通用 LLM 的对应优化链记为：
```text
QKV GEMM
→ fused RoPE / layout
→ FlashAttention
→ output projection + residual epilogue
→ fused RMSNorm
→ fused SwiGLU
→ down projection + residual epilogue
```
其中 LoMa-B 的 F1、F2、F3 分别对应这条链里的 Attention 前处理、Norm/激活融合、以及 residual epilogue。

# LLM推理工程
从 LLM 推理引擎的角度看，性能不是单靠某个 FlashAttention 或融合 kernel 获得的，而是一条完整执行链的结果：
```text
先决定用哪种算子实现
→ 再把数据准备成该实现最适合的布局
→ 复用已经申请、构建好的资源
→ 在执行模式稳定时，用 CUDA Graph 降低调度开销
```

这四部分可以理解为 LLM runtime 的“执行优化层”：
```text
1. Backend dispatch：决定怎么算
2. Tensor / layout 准备：决定数据怎样摆放
3. 资源缓存与复用：避免重复准备
4. CUDA Graph：减少 CPU 发射 kernel 的成本
```
在完整 LLM 系统中，它们前面还会有请求调度、continuous batching、prefill/decode 分流、KV Cache 管理；这四部分则负责把已确定的 batch 高效地送上 GPU。

---

## 1. Backend dispatch：决定“这次 Attention/GEMM 应该怎么跑”

同一个 Attention 公式，有不同实现：
```text
FlashAttention
cuDNN SDPA
PagedAttention
decode 专用 kernel
通用 fallback
```

它们数学语义相同，但适合的条件不同。LLM runtime 要根据运行状态选择。
```python
if phase == "prefill" and dtype in [BF16, FP16]:
    backend = FlashAttention

elif phase == "decode" and kv_cache_is_paged:
    backend = PagedAttention

elif shape_matches_cudnn_plan:
    backend = cuDNN_SDPA

else:
    backend = fallback
```

LLM 中最关键的选择维度包括：
- 阶段：prefill 还是 decode；
- GPU 架构：SM80、SM89、SM90 等；
- 精度：BF16、FP8 等；
- `Q` 的长度、KV Cache 长度、head_dim；
- Attention 形式：MHA、GQA、MLA；
- KV Cache 的内存布局：连续还是分页。

LoMa-B 的对应实现较简单：SM89 的 BF16 route 明确选择 PyTorch FlashAttention；SM80/SM90 使用 cuDNN SDPA。它体现的是同一原则：**不要让同一种算子实现覆盖所有硬件和所有 shape。**

---

## 2. Tensor / layout 准备：让数据以 kernel 最喜欢的形式进入 GPU

高性能 kernel 往往不是“拿任意 Tensor 都能最快跑”。例如 FlashAttention 希望 Q/K/V 的 dtype、shape、stride 和布局满足要求。

LLM 中理想路径是：
```text
hidden states
→ QKV GEMM
→ fused RoPE
→ 直接写为 Attention / KV Cache 所需布局
→ Attention
```
而不是：
```text
QKV GEMM
→ split Q/K/V
→ 单独 RoPE
→ transpose
→ contiguous copy
→ 再写 KV Cache
→ Attention
```
后者虽然结果相同，但会产生大量额外显存读写。

LoMa-B 的 `QKV split + RoPE + Flash layout` 融合就是这一思想的实例：QKV Linear 的输出被一次 kernel 处理，直接得到 FlashAttention 可使用的 `[B, H, T, D]` 数据。

对 LLM 来说，进一步要关注：
```text
Q：直接进入 Attention
K/V：除供当前 Attention 使用外，还要直接写入 KV Cache
```

因此真正优秀的 LLM 实现通常会尽量把：
```text
QKV 投影 + RoPE + KV Cache 写入 + layout 转换
```
安排成最少的 kernel 和最少的中间 Tensor。

这里的核心原则是：
> GPU 上很多时候不是算不够快，而是 Tensor 被反复重排、复制和读回，导致显存带宽成为瓶颈。

---

## 3. 资源缓存与复用：避免每次请求重新“搭台”

推理中有大量资源不会随每次请求改变：
```text
模型权重
Attention workspace
GEMM workspace
cuDNN execution plan
临时 activation buffer
CUDA Graph 静态输入输出 buffer
```
如果每次请求都重新创建这些对象，就会浪费 CPU 时间、CUDA 内存分配时间，甚至触发同步。

可以按生命周期理解：

| 生命周期       | 应复用的资源                                         |
| ---------- | ---------------------------------------------- |
| 模型生命周期     | 权重、量化权重、常驻 workspace                           |
| shape 生命周期 | cuDNN plan、Flash/GEMM 的 shape bucket、临时 buffer |
| 请求生命周期     | token slot、输出 buffer、KV Cache block            |
| batch 生命周期 | batch metadata、block table、graph 输入槽位          |
LoMa-B 中会缓存 BF16 权重、cuDNN Attention plan、workspace 和输出 buffer；相同 token 数再次执行时可直接复用。

LLM 中最重要、但 LoMa-B 不具备的缓存是：
```text
KV Cache
```

它保存已处理 token 的 K/V，使 decode 时不必重新计算历史上下文：
```text
历史 token
→ 已经生成 K/V
→ 保存在 KV Cache

新 token
→ 只计算新的 Q/K/V
→ Q 读取历史 KV Cache
```

因此，对 LLM runtime 而言，资源复用的核心从“复用 workspace”进一步扩展为：
```text
权重复用
+ workspace 复用
+ KV Cache 生命周期管理
+ paged block 分配与回收
```

---

## 4. CUDA Graph：减少 CPU 不断发射 kernel 的开销

即使每个 kernel 都足够快，CPU 仍可能成为瓶颈：
```text
CPU launch QKV
CPU launch RoPE
CPU launch Attention
CPU launch RMSNorm
CPU launch MLP
CPU launch sampling
...
```
尤其在 LLM decode 阶段，每步只生成少量 token、GPU 单次计算较短，CPU 的 kernel launch 开销会更突出。

CUDA Graph 的方式是：
```text
第一次：
固定 shape、buffer 地址和执行路径
→ capture 整串 GPU kernel

之后：
更新静态输入 buffer
→ graph.replay()
```

即：
```text
多次 CPU launch
↓
一次 replay
```

LLM 中通常更适合在 decode 使用 CUDA Graph：

| 阶段 | CUDA Graph 价值 |
|---|---|
| Prefill | 有价值，但长序列计算本身较重，launch 占比相对较低 |
| Decode | 很重要；每步计算小、调用频繁，launch 开销占比更高 |

但 CUDA Graph 有硬约束：
```text
shape 稳定
batch size 稳定或落入 bucket
buffer 地址稳定
控制流稳定
所选 backend 稳定
```

所以生产 LLM 不会只维护一张 graph，而常按 bucket 缓存：
```text
batch = 1 / 2 / 4 / 8 / 16 ...
KV length = 若干区间
dtype / backend / 模型配置
→ 对应不同 CUDA Graph
```
不能命中 bucket 或请求形状变化太大时，则回退到 eager 路径。

LoMa-B 也采用相同思路：只有 token 数、batch、阈值、剪枝模式和输入类型等条件匹配已捕获图时，才会 replay；否则不强行使用 CUDA Graph。

---

## 四部分的逻辑关系

```text
请求已被调度为一个 batch
→ backend dispatch：选 FlashAttention / cuDNN / PagedAttention
→ layout planner：准备 QKV、KV Cache 和正确 stride
→ resource cache：取已有 workspace、plan、buffer
→ stable shape：命中 CUDA Graph 则 replay
→ 否则 eager 执行
```

可以把它总结成一句 LLM runtime 的设计原则：
> 先选择最适合当前请求的 kernel，再避免为这个 kernel 做额外搬运，随后复用一切可复用资源；当执行条件稳定时，把整段 GPU 调度固化为 CUDA Graph。